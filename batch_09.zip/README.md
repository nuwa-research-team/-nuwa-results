# D4 traffic-imputation experiments (2026-11-14 to 2026-11-16)

本目录是最近实验的 GitHub 上传快照：代码、固定样本/掩码、提示词、逐流预测、指标与失败记录。所有目录使用英文。原工作区未移动或删除。

| Directory | Contents |
|---|---|
| 01_code | Archived experiment/API/reporting code; offline metric verifier |
| 02_data | Fixed A/B 1000-draw cohorts, dev/confirmation 200-flow cohorts, head-training panels |
| 03_teacher_comparison | Gemini/DeepSeek/Luna teacher comparisons and available intermediate records |
| 04_prompt_study | Original/local-context/behavior/examples prompt experiment |
| 05_integrated_prompt | Integrated prompt experiment |
| 06_luna_parameters | Latest original-prompt parameter tuning versus fixed P2 prompt |
| 07_head_pilot | Separate numeric-head experiments and diagnostics; historical side branch |
| 08_api_records_deepseek / gemini / luna | API answers/attempt journals packed into JSONL, with original paths and hashes |
| 09_documentation | Provenance, exclusions, sizes, security scan, snapshot manifest |

## Latest completed result / 最新结论

同200条开发流、30%固定缺包，六个冻结分类器平均。以下是本轮重新调用的数据，不与历史最好结果混用。

| Method | Accuracy (%) | macro-F1 (%) | Magnitude MAE (bytes) | Valid (%) |
|---|---:|---:|---:|---:|
| Luna P0, original parameters, repeated | 54.25 | 52.90 | 131.79 | 99.0 |
| P0, medium reasoning request | 53.75 | 45.39 | 127.95 | 98.0 |
| P0, high reasoning request | 54.00 | 52.74 | 142.03 | 95.5 |
| P0, temperature=0 | 53.50 | 49.62 | 132.70 | 99.5 |
| P2 optimized prompt, repeated | 53.75 | 42.12 | 149.59 | 99.0 |
| Local TFI | 57.00 | 54.30 | 91.90 | 100.0 |

No parameter setting passed the predeclared improvement gate. The train-derived candidate-selection experiment has been discussed but NOT implemented or run at this snapshot; it is pending while this package is prepared.

## Recheck saved metrics / 离线复核

From this repository root run:

```text
python 01_code/verify_saved_metrics.py
```

This uses Python's standard library, saved predictions and labels only. It makes no API calls and does not train models. It verifies arithmetic, not end-to-end model reproduction.

## What is intentionally not included

Model checkpoints, frozen feature caches, raw PCAPs, large binary training assets, virtual environments, account quotas/billing snapshots and authentication files are excluded. See `09_documentation/excluded_files.json` for the exact inventory; originals remain in the workspace. This package includes extracted numeric data, not a complete raw D4 distribution.

The original experiment scripts in `01_code` are research-source snapshots, not a ready-to-run independent training package. They reference the original workspace layout, external Nüwa/downstream code and excluded model assets. Their local paths were normalized where necessary. Restore dependencies and configure credentials separately before using them; running some API scripts incurs calls. Only the offline verifier above is tested as standalone here.

## Provenance and boundaries

API records are consolidated to reduce upload file count, not discarded. Each JSONL record retains its original relative filename and original SHA256. Personal local paths/account metadata and detectable secrets were sanitized. Original manifests remain historical provenance, and are not executable validations of this rearranged export. `09_documentation/package_manifest.json` describes the export's hashes instead.

The 200-flow development set was used repeatedly; results are exploratory, not an independent final benchmark. Teacher names are platform-advertised identities. Local TFI is a local implementation reference, not a claim of exact official-paper reproduction. Do not compare different cohorts as paired experiments. B1000 includes replacement draws; keep its original multiplicity. Miuref has only two flows in the dev200 cohort.

For older teacher jobs, this snapshot preserves files that are currently local. A script's existence or a historical progress file does not prove its job completed. Missing final artifacts are not reconstructed or invented.

## Upload

Use the sibling `upload_batches` directories for browser upload: each batch contains at most 80 files and at most 8 MiB of uncompressed content. Open one batch and upload its CONTENTS to the same repository root, then commit. Do not upload the outer batch directory itself. Repeat all batches.

The sibling ZIP files are optional transfer backups. GitHub does not automatically expand an uploaded ZIP into browsable source files. Upload either the unpacked batches for a normal repository, or ZIPs as archives; do not upload all duplicate copies.

GitHub's browser limit is 25 MiB per file and up to 100 files per upload: https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository
