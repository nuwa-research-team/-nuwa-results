# ReSTC 在 ISCX VPN-nonVPN 2016 上的 662 条留出流实验

下载后用浏览器打开 [完整实验总表](reports/all_tables.html)。21 张三线表依次报告丢包补全对照、模型参数量、鲁棒性、LoRA 秩比较、四组累积消融，以及包长误差附表。GitHub 网页可直接查看本说明及 JSON。HTML 支持离线查看。

评估集包含 334 条普通流和 328 条 VPN 流。每条流各测 10%、30%、50% 三档丢包，每个掩码方案含 1,986 个流与丢包率组合。随机掩码使用种子 42 和 137，连续丢包使用种子 137。具体样本支持数与划分统计见 [评估配置](settings/evaluation.json)。

## 指标与对照

Normal 表示完整流。Acc 和 macro-F1 均以百分数显示，macro-F1 对评估子集中有真实样本的类别取平均。主表的六分类器平均值对 CNN、LSTM、GRU、TST、SDAE、FS-Net 等权计算。RF、SVM 另列。包长 MAE 仅在缺包位置比较预测与真实包长的绝对幅值，以字节计。各丢包率按实际缺包数加权。

AB 使用掩码和基座约束补全，ABC 加入可见包行为预处理，ABCD 加入教师蒸馏适配器，ABCDE 继续用 D4 训练集真实包长微调。最终学生为 SmolLM2-135M，LoRA 秩为 8。TFI 为相同掩码下的本地实现。教师与其他对照的有效输出、回退口径及实验范围见总表表注。

## 文件与复核

- `reports/` 保存完整三线表。
- `results/r8_metrics.json` 保存各分类器未四舍五入的百分数。每个数组依次为 Normal、10%、30%、50% 的 Acc 和 macro-F1。MAE 的三个元素对应三个丢包率。
- `results/conditions.json` 给出每个预测文件的掩码和源评分记录中的包长 MAE。`reference_135m` 为原 r=16 蒸馏对照。`results/parameter_counts_r16.json` 为原始 r=16 参数记录，各秩参数对比见总表。
- `evaluation/` 保存匿名流标识、真实应用标签、流量模式、带方向包长、三套缺包位置和 r=8 最后两组的逐位置包长预测。位置采用从零开始的下标。
- `predictions/` 保存各条件下八个分类器的逐流预测。每个压缩 JSON 的数组按对应掩码文件的行顺序排列。`settings/` 保存评估设置、最终训练配置及适配器哈希。
- 在本目录运行 `python verify.py` 可离线校验文件哈希、复算 r=8 结果文件中的分类指标，以及 ABCD 和 ABCDE 的包长 MAE。其余方法的包长 MAE 保留源评分汇总值。复核无需 GPU，仅用 Python 3 标准库。

数据来源为 [University of New Brunswick 的 ISCX VPN-nonVPN 2016](https://www.unb.ca/cic/datasets/vpn.html)。本目录用于分享结果和逐流核验，重新训练还需基座、训练数据、适配器及分类器权重。
