"""Verify the packaged results offline with Python 3."""
import gzip
import hashlib
import json
from collections import Counter
from math import isclose
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RATES = (0.1, 0.3, 0.5)
CORE = ('cnn', 'lstm', 'gru', 'tst', 'sdae', 'fsnet')


def load(name):
    data = (ROOT / name).read_bytes()
    if name.endswith('.gz'):
        data = gzip.decompress(data)
    return json.loads(data)


def close(actual, expected):
    if not isclose(actual, expected, rel_tol=1e-11, abs_tol=1e-10):
        raise ValueError(f'{actual} differs from {expected}')


def scores(truth, predicted):
    correct = Counter(a for a, b in zip(truth, predicted) if a == b)
    counts, guessed = Counter(truth), Counter(predicted)
    accuracy = 100 * sum(correct.values()) / len(truth)
    macro = 100 * sum(2 * correct[c] / (counts[c] + guessed[c]) for c in counts) / len(counts)
    return accuracy, macro


def main():
    for line in (ROOT / 'SHA256SUMS').read_text(encoding='utf-8').splitlines():
        expected, name = line.split('  ', 1)
        if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != expected:
            raise ValueError(f'Hash mismatch in {name}')
    flows = load('evaluation/flows.json.gz')
    normal = load('predictions/reference_normal.json.gz')
    summaries = load('results/r8_metrics.json')
    runs = {'随机42 · r=8': 'rank8', '随机42 · TFI': 'reference_tfi',
            '随机137 · r=8': 'r8_random137', '随机137 · TFI': 'tfi_random137',
            '连续137 · r=8': 'r8_burst137', '连续137 · TFI': 'tfi_burst137',
            'AB': 'AB', 'ABC': 'ABC', 'ABCD': 'r8_ABCD', 'ABCDE': 'r8_ABCDE'}
    if runs.keys() != summaries.keys():
        raise ValueError('The set of r=8 conditions has changed')
    conditions = load('results/conditions.json')
    for title, run in runs.items():
        mask = conditions[run]['mask']
        cases = load(f'evaluation/{mask}.json.gz')
        pred = load(f'predictions/{run}.json.gz')
        lengths = load(f'evaluation/{run}_lengths.json.gz') if title in ('ABCD', 'ABCDE') else None
        expected = summaries[title]
        for index, rate in enumerate((0,) + RATES):
            ids = [i for i, (_, r, _) in enumerate(cases) if r == (rate or 0.1)]
            if len(ids) != 662 or len({cases[i][0] for i in ids}) != 662:
                raise ValueError(f'Invalid flow set in {run}')
            truth = [flows[cases[i][0]]['label'] for i in ids]
            classifiers = pred if rate else normal
            results = {}
            for clf, labels in classifiers.items():
                results[clf] = scores(truth, [labels[i] for i in ids])
                for j, value in enumerate(results[clf]):
                    close(value, expected['metrics'][clf][2 * index + j])
            for j in (0, 1):
                close(sum(results[c][j] for c in CORE) / len(CORE),
                      expected['metrics']['six'][2 * index + j])
            if rate and lengths is not None:
                total, count = 0, 0
                for i in ids:
                    flow_id, _, positions = cases[i]
                    if len(lengths[i]) != len(positions):
                        raise ValueError(f'Missing predictions in {run}')
                    for position, value in zip(positions, lengths[i]):
                        total += abs(abs(value) - abs(flows[flow_id]['truth'][position]))
                        count += 1
                close(total / count, expected['mae'][index - 1])
    print('PASS: file hashes, 10 classification conditions, and six paired packet MAEs.')


if __name__ == '__main__':
    main()
