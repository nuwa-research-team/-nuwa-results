"""Requires explicit class list; never guesses the paper's missing USTC subset."""
import argparse, collections, json
from pathlib import Path
import numpy as np
from sklearn.model_selection import train_test_split
from core import file_hash, write_json

p=argparse.ArgumentParser(); p.add_argument('--sequences',required=True,type=Path); p.add_argument('--labels',required=True)
p.add_argument('--output',required=True,type=Path); p.add_argument('--dataset',required=True); p.add_argument('--scope',choices=['engineering','paper_aligned'],default='engineering')
args=p.parse_args(); labels=args.labels.split(','); selected=[]
if len(set(labels))!=len(labels) or len(labels)<2: raise ValueError('Need distinct explicit labels')
for path in sorted(args.sequences.glob('*.jsonl')):
    with path.open(encoding='utf-8') as f:
        selected.extend(json.loads(line) for line in f if json.loads(line)['label'] in labels)
counts=collections.Counter(r['label'] for r in selected)
if any(counts[label]<10 for label in labels): raise ValueError('Too few rows for split: '+str(counts))
ids=np.array([r['id'] for r in selected]); y=np.array([labels.index(r['label']) for r in selected]); n=np.array([len(r['lengths']) for r in selected])
if len(set(ids.tolist()))!=len(ids): raise ValueError('Duplicate source stream identities')
x=np.zeros((len(selected),512),dtype=np.int16)
for i,row in enumerate(selected): x[i,:n[i]]=row['lengths']
indices=np.arange(len(y)); train,test=train_test_split(indices,test_size=.2,stratify=y,random_state=42)
train,val=train_test_split(train,test_size=.1,stratify=y[train],random_state=42)
roles=np.empty(len(y),dtype='U5'); roles[train]='train'; roles[val]='val'; roles[test]='test'
groups=collections.defaultdict(set)
for row,role in zip(selected,roles): groups[row['length_sha256']].add(str(role))
crossing=sum(len(v)>1 for v in groups.values())
# Equal coarse feature sequences can belong to independent real flows. Report them;
# they are not, by themselves, proof of identity leakage or grounds to change splits.
args.output.mkdir(parents=True,exist_ok=True)
np.savez_compressed(args.output/'dataset.npz',x=x,y=y,lengths=n,ids=ids,roles=roles)
write_json(args.output/'metadata.json',{'dataset':args.dataset,'scope':args.scope,'classes':labels,'counts':dict(counts),
    'split_seed':42,'test_fraction':.2,'val_fraction_of_remaining':.1,'rows':len(y),'normalization':1600,
    'duplicate_feature_groups_crossing_roles':crossing,'duplicate_feature_note':'Equal features do not establish same real session; source-stream IDs are unique',
    'npz_sha256':file_hash(args.output/'dataset.npz')})
print(json.dumps({'rows':len(y),'classes':labels,'counts':dict(counts),'roles':dict(collections.Counter(roles.tolist()))}))
