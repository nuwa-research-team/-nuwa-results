"""Preserve original extraction; normalize archive chunk labels in a new derivative."""
import collections,json
from pathlib import Path
from core import write_json,file_hash
root=Path(__file__).resolve().parent.parent
base=root/'data/processed/USTC-TFC2016';dest=base/'sequences_canonical';dest.mkdir(exist_ok=True)
inventory=json.loads((base/'inventory.json').read_text());counts=collections.Counter(); reports=[]
for item in inventory:
    src=Path(item['source']); label=src.parent.name if 'expanded' in src.parts else src.stem
    path=Path(item['output']); target=dest/(label+'_'+item['source_sha256'][:12]+'.jsonl')
    with path.open(encoding='utf-8') as f,target.open('w',encoding='utf-8') as out:
        for line in f:
            row=json.loads(line);row['original_chunk_label']=row['label'];row['label']=label
            out.write(json.dumps(row,separators=(',',':'))+'\n');counts[label]+=1
    reports.append({'label':label,'source_sha256':item['source_sha256'],'original_sequence_sha256':item['output_sha256'],
        'canonical_path':str(target),'canonical_sha256':file_hash(target),'retained':item['retained']})
write_json(base/'canonical_inventory.json',{'source_inventory_sha256':file_hash(base/'inventory.json'),'files':reports,'counts':dict(counts),
    'total':sum(counts.values()),'parity_status':'tshark implementation; exact flowcontainer parity not yet established'})
print(json.dumps({'retained':sum(counts.values()),'classes':dict(counts)}))
