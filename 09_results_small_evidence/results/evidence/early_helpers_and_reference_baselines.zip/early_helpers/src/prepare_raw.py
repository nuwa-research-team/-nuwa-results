"""Read-only PCAP -> audited TCP length sequences. No training or replay."""
import argparse, collections, hashlib, json, subprocess, sys, time
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parent.parent/'.deps'))

def sha256(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for block in iter(lambda:f.read(8<<20),b''): h.update(block)
    return h.hexdigest()

def expand(raw, dest):
    import py7zr
    found=list(raw.rglob('*.pcap'))+list(raw.rglob('*.pcapng'))
    for archive in sorted(raw.rglob('*.7z')):
        target=dest/archive.stem
        marker=target/'extraction.done.json'
        if marker.exists():
            found.extend(target.rglob('*.pcap')); found.extend(target.rglob('*.pcapng')); continue
        with py7zr.SevenZipFile(archive,'r') as z:
            entries=z.list()
            for entry in entries:
                name=Path(entry.filename)
                if name.is_absolute() or '..' in name.parts or ':' in entry.filename:
                    raise ValueError('Unsafe archive path')
                if not entry.is_directory and name.suffix.lower() not in ('.pcap','.pcapng'):
                    raise ValueError('Unexpected archive content: '+entry.filename)
            if sum(e.uncompressed for e in entries if not e.is_directory)>100*(1<<30):
                raise ValueError('Archive exceeds extraction space budget')
            target.mkdir(parents=True,exist_ok=True)
            z.extractall(path=target)
        marker.write_text(json.dumps({'source_sha256':sha256(archive),'files':[e.filename for e in entries]}),encoding='utf-8')
        found.extend(target.rglob('*.pcap')); found.extend(target.rglob('*.pcapng'))
    return sorted(set(found))

def extract(path, label, output, tshark):
    output.mkdir(parents=True,exist_ok=True)
    source_hash=sha256(path); target=output/(label+'_'+source_hash[:12]+'.jsonl')
    audit=target.with_suffix('.audit.json')
    if audit.exists() and target.exists(): return json.loads(audit.read_text())
    fields=['tcp.stream','ip.src','ipv6.src','tcp.srcport','ip.len','ipv6.plen','frame.time_epoch']
    command=[tshark,'-n','-2','-r',str(path),'-Y','tcp && !tcp.analysis.retransmission','-T','fields','-E','occurrence=f']
    for field in fields: command+=['-e',field]
    start=time.monotonic(); streams={}; packet_count=0
    log=output/(target.stem+'.tshark.log')
    with log.open('w',encoding='utf-8') as err:
        process=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=err,text=True,encoding='utf-8')
        for line in process.stdout:
            values=line.rstrip('\r\n').split('\t')
            if len(values)!=7 or not values[0]: continue
            stream,ipv4,ipv6,port,iplen,ip6len,stamp=values
            if not (iplen or ip6len): continue
            # IPv6 total length includes the fixed 40-byte base header.
            length=int(iplen) if iplen else int(ip6len)+40
            key=(ipv4 or ipv6,port)
            row=streams.setdefault(stream,{'origin':key,'n':0,'bad':False,'lengths':[],'timestamps':[]})
            row['n']+=1; packet_count+=1; row['bad'] |= length>1600
            if len(row['lengths'])<512:
                row['lengths'].append(length if key==row['origin'] else -length)
                row['timestamps'].append(float(stamp))
        code=process.wait()
        if code: raise RuntimeError('tshark failed: '+str(log))
    reasons=collections.Counter(); retained=0
    partial=target.with_suffix('.partial')
    with partial.open('w',encoding='utf-8') as out:
        for stream,row in streams.items():
            reason='short' if row['n']<20 else 'oversized' if row['bad'] else 'retained'
            reasons[reason]+=1
            if reason!='retained': continue
            retained+=1
            item={'id':source_hash+':tcp:'+stream,'label':label,'source_sha256':source_hash,'tcp_stream':int(stream),
                  'packet_count':row['n'],'lengths':row['lengths'],'timestamps':row['timestamps'],
                  'length_sha256':hashlib.sha256(json.dumps(row['lengths'],separators=(',',':')).encode()).hexdigest()}
            out.write(json.dumps(item,separators=(',',':'))+'\n')
    partial.replace(target)
    report={'source':str(path),'source_sha256':source_hash,'source_bytes':path.stat().st_size,'label':label,
            'packets':packet_count,'streams':len(streams),'retained':retained,'filters':dict(reasons),
            'seconds':time.monotonic()-start,'output_sha256':sha256(target),'output':str(target),
            'implementation':'tshark TCP stream, first packet endpoint defines positive direction; flowcontainer parity pending'}
    audit.write_text(json.dumps(report,indent=2),encoding='utf-8'); return report

if __name__=='__main__':
    parser=argparse.ArgumentParser(); parser.add_argument('--raw',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True); parser.add_argument('--tshark',required=True)
    args=parser.parse_args(); args.output.mkdir(parents=True,exist_ok=True)
    files=expand(args.raw,args.output/'expanded'); reports=[]
    for index,path in enumerate(files):
        label=path.stem
        report=extract(path,label,args.output/'sequences',args.tshark); reports.append(report)
        print(json.dumps({'file':index+1,'total':len(files),'label':label,'retained':report['retained'],'seconds':round(report['seconds'],2)}),flush=True)
        (args.output/'inventory.json').write_text(json.dumps(reports,indent=2),encoding='utf-8')
