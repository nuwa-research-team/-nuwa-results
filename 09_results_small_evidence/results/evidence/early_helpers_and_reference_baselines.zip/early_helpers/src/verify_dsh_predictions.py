"""Independently recompute DSH metrics; this is not a training reproduction."""
import argparse,json
from pathlib import Path
import numpy as np
from sklearn.metrics import accuracy_score,f1_score,confusion_matrix
from core import file_hash,write_json
p=argparse.ArgumentParser();p.add_argument('--results',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
p.add_argument('--scope',required=True);p.add_argument('--test',type=Path)
a=p.parse_args();results=json.loads((a.results/'metrics.json').read_text());checks=[];reference=None
if a.test:
    with np.load(a.test,allow_pickle=False) as z:reference=z['y']
for result in results:
    model=result['model']
    for condition,reported in result['conditions'].items():
        path=a.results/'predictions'/f'{model}_{condition}.npz'
        with np.load(path,allow_pickle=False) as z:y=z['y'];pred=z['pred'];has_ids='ids' in z
        if y.shape!=pred.shape or y.ndim!=1:raise ValueError('Prediction shape mismatch')
        if reference is None:reference=y.copy()
        if not np.array_equal(y,reference):raise ValueError('Target labels differ across conditions or test')
        calculated={'acc':accuracy_score(y,pred)}
        calculated.update({f'f1_{avg}':f1_score(y,pred,average=avg,zero_division=0) for avg in ['macro','weighted','micro']})
        differences={k:abs(v-reported[k]) for k,v in calculated.items()}
        if max(differences.values())>5.01e-6:raise ValueError((model,condition,differences))
        classes=len(reported['support']);cm=confusion_matrix(y,pred,labels=list(range(classes)))
        if not np.array_equal(cm,np.asarray(reported['confusion'])):raise ValueError('Confusion matrix mismatch')
        if not np.array_equal(cm.sum(1),np.asarray(reported['support'])):raise ValueError('Support mismatch')
        checks.append({'model':model,'condition':condition,'rows':len(y),'status':'PASS','max_rounding_difference':max(differences.values()),
            'prediction_sha256':file_hash(path),'metrics':calculated,'per_flow_ids_saved':has_ids})
write_json(a.output,{'scope':a.scope,'verification':'arithmetic_and_condition_label_consistency_only',
    'independent_test_label_reference':a.test is not None,'source_metrics_sha256':file_hash(a.results/'metrics.json'),
    'checkpoint_reinference':False,'strict_paper_reproduction':False,'checks':checks})
print(json.dumps({'conditions':len(checks),'status':'PASS','scope':a.scope,'per_flow_ids_saved':all(x['per_flow_ids_saved'] for x in checks)}))
