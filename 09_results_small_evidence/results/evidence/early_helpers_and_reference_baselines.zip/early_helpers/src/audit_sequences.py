"""No fitting: length distribution and duplicate-identity checks before splitting."""
import collections,json,statistics
from pathlib import Path
from core import write_json
root=Path(__file__).resolve().parent.parent
records=[]
for path in sorted((root/'data/processed/USTC-TFC2016/sequences_canonical').glob('*.jsonl')):
    with path.open(encoding='utf-8') as f:
        for line in f:
            r=json.loads(line);records.append((r['id'],r['label'],len(r['lengths']),r['length_sha256']))
groups=collections.defaultdict(list)
for r in records:groups[r[3]].append(r)
lengths=sorted(r[2] for r in records)
result={'rows':len(records),'unique_source_stream_ids':len({r[0] for r in records}),
    'unique_length_sequences':len(groups),'duplicate_sequence_groups':sum(len(v)>1 for v in groups.values()),
    'rows_in_duplicate_groups':sum(len(v) for v in groups.values() if len(v)>1),
    'cross_label_sequence_groups':sum(len({r[1] for r in v})>1 for v in groups.values()),
    'length':{'mean':statistics.mean(lengths),'median':statistics.median(lengths),
        'p90':lengths[int(.9*len(lengths))],'p99':lengths[int(.99*len(lengths))],'max':max(lengths)},
    'note':'Duplicate feature sequences are not automatically the same session; preserve source IDs and report overlap before choosing a split policy.'}
write_json(root/'audit/sequence_identity_audit.json',result);print(json.dumps(result))
