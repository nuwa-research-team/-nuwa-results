"""Train on train, select on val, evaluate once with paired held-out corruptions."""
import argparse,json,time
from pathlib import Path
import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader,TensorDataset
from core import seed_all,write_json,file_hash,metrics,loss_mask,corrupt,Markov
from models import make_classifier,SDAE,FSNet

def predict(model,x,lengths,device):
    model.eval(); outputs=[]
    with torch.inference_mode():
        for start in range(0,len(x),128):
            outputs.append(model(torch.tensor(x[start:start+128],device=device,dtype=torch.float32)/1600,
                torch.tensor(lengths[start:start+128],device=device)).argmax(1).cpu().numpy())
    return np.concatenate(outputs)

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--dataset',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--model',choices=['CNN','LSTM','GRU','TST','SDAE','FS-Net'],required=True)
    p.add_argument('--device',default='cuda');p.add_argument('--seed',type=int,default=42);p.add_argument('--epochs',type=int,default=30)
    p.add_argument('--engineering-limit',type=int,default=0)
    args=p.parse_args(); seed_all(args.seed);torch.set_num_threads(min(4,torch.get_num_threads()))
    data=np.load(args.dataset,allow_pickle=False); metadata=json.loads(args.dataset.with_name('metadata.json').read_text())
    x=data['x'];y=data['y'];n=data['lengths'];ids=data['ids'];roles=data['roles']; classes=len(metadata['classes'])
    train=np.flatnonzero(roles=='train');val=np.flatnonzero(roles=='val');test=np.flatnonzero(roles=='test')
    if args.engineering_limit:
        rng=np.random.default_rng(args.seed);train=rng.permutation(train)[:args.engineering_limit]
        val=rng.permutation(val)[:512];test=rng.permutation(test)[:512]
    args.output.mkdir(parents=True,exist_ok=False); model=make_classifier(args.model,classes).to(args.device)
    config={k:str(v) if isinstance(v,Path) else v for k,v in vars(args).items()}
    config.update(dataset_sha256=file_hash(args.dataset),metadata=metadata,scope='engineering' if args.engineering_limit else metadata['scope'],
        parameters=sum(p.numel() for p in model.parameters()),classifier_configuration='declared_reimplementation_not_author_config',
        roles={r:len(indices) for r,indices in [('train',train),('val',val),('test',test)]},versions={'torch':torch.__version__,'numpy':np.__version__})
    write_json(args.output/'run.json',config)
    np.savez_compressed(args.output/'role_ids.npz',train=ids[train],val=ids[val],test=ids[test])
    loader=DataLoader(TensorDataset(torch.tensor(x[train],dtype=torch.float32)/1600,torch.tensor(n[train]),torch.tensor(y[train])),batch_size=128,shuffle=True)
    optimizer=torch.optim.Adam(model.parameters(),lr=.001,weight_decay=0); best=-1;start=time.monotonic()
    with (args.output/'epochs.jsonl').open('w') as log:
        for epoch in range(args.epochs):
            model.train(); losses=[];t0=time.monotonic()
            for xx,nnn,yy in loader:
                xx,nnn,yy=xx.to(args.device),nnn.to(args.device),yy.to(args.device)
                optimizer.zero_grad()
                loss=model.supervised_loss(xx,nnn,yy) if isinstance(model,FSNet) else nn.functional.cross_entropy(model(xx,nnn),yy)
                # Explicit SDAE joint denoising auxiliary loss; not claimed exact greedy pretraining.
                if isinstance(model,SDAE): loss=loss+.1*model.denoising_loss(xx)
                if not torch.isfinite(loss): raise RuntimeError('Nonfinite classification loss')
                loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),5);optimizer.step();losses.append(float(loss.detach()))
            pred=predict(model,x[val],n[val],args.device);score=metrics(y[val],pred,classes)['F1_macro']
            if score>best:
                best=score;torch.save(model.state_dict(),args.output/'best.pt');write_json(args.output/'selection.json',{'epoch':epoch+1,'val_F1_macro':score})
            record={'epoch':epoch+1,'loss':float(np.mean(losses)),'val_F1_macro':score,'epoch_seconds':time.monotonic()-t0}
            log.write(json.dumps(record)+'\n');log.flush();print(json.dumps(record),flush=True)
    model.load_state_dict(torch.load(args.output/'best.pt',map_location=args.device,weights_only=True))
    markov=Markov().fit(x[train],n[train]);results=[]
    for ratio in [0,.1,.2,.3]:
        mask=loss_mask(ids[test],n[test],ratio,width=x.shape[1]);np.savez_compressed(args.output/f'mask_{ratio}.npz',ids=ids[test],mask=mask)
        for method in (['clean'] if ratio==0 else ['deletion','ZeroPad','Markov']):
            xx,nnn=(markov.impute(x[test],n[test],mask),n[test]) if method=='Markov' else corrupt(x[test],n[test],mask,method)
            pred=predict(model,xx,nnn,args.device);result={'method':method,'loss_rate':ratio,**metrics(y[test],pred,classes)}
            if mask.any():result['missing_only_RMSE_normalized']=float(np.sqrt(np.mean(((xx-x[test])/1600)[mask]**2))) if method!='deletion' else None
            results.append(result);np.savez_compressed(args.output/f'pred_{method}_{ratio}.npz',ids=ids[test],y=y[test],pred=pred)
    write_json(args.output/'metrics.json',results);write_json(args.output/'done.json',{'seconds':time.monotonic()-start,'best_checkpoint_sha256':file_hash(args.output/'best.pt'),'test_used_for_selection':False})
    (args.output/'fit.done').write_text('complete\n');print(json.dumps({'done':str(args.output),'seconds':time.monotonic()-start}))
