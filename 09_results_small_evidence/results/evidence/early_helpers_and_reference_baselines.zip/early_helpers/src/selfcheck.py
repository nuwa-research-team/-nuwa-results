"""Engineering checks only; generated tensors are never paper experiment results."""
import json,sys,time
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parent.parent/'.deps'))
import numpy as np
import torch
from core import seed_all,loss_mask,corrupt,metrics,Markov,write_json
from models import make_classifier,FSNet
from mlm import make_mlm,noise,impute
torch.set_num_threads(2); seed_all(42); reports=[]; start=time.monotonic()
for name in ['CNN','LSTM','GRU','TST','SDAE','FS-Net']:
    model=make_classifier(name,3,seq_len=32)
    x=torch.randn(3,32).clamp(-1,1);n=torch.tensor([32,25,20]);y=torch.tensor([0,1,2])
    logits=model(x,n);assert logits.shape==(3,3) and torch.isfinite(logits).all()
    loss=model.supervised_loss(x,n,y) if isinstance(model,FSNet) else torch.nn.functional.cross_entropy(logits,y)
    loss.backward();assert all(torch.isfinite(p.grad).all() for p in model.parameters() if p.grad is not None)
    reports.append({'check':'classifier_forward_backward','name':name,'loss':float(loss.detach()),'status':'PASS'})
for name in ['BERT','Roberta','Deberta','Nuwa-source-repair','TFM-slot-approx']:
    model=make_mlm(name,80,tiny=True);tokens=torch.randint(5,80,(3,32));tokens[1,25:]=1
    g=torch.Generator().manual_seed(42);inputs,labels=noise(tokens,'slot_approx' if name=='TFM-slot-approx' else 'standard',g)
    assert (labels[tokens==1]==-100).all()
    loss=model(input_ids=inputs,attention_mask=tokens.ne(1),labels=labels).loss;loss.backward()
    assert torch.isfinite(loss) and all(torch.isfinite(p.grad).all() for p in model.parameters() if p.grad is not None)
    xx=np.tile(np.arange(20,52,dtype=np.int16),(3,1)); nn=np.array([32,25,20]); mm=loss_mask(['a','b','c'],nn,.2,width=32)
    filled=impute(model,xx,nn,mm,np.arange(75)+5,'cpu')
    assert np.array_equal(filled[~mm],xx[~mm])
    reports.append({'check':'mlm_forward_backward_decode_preserves_observed','name':name,'status':'PASS'})
ids=np.array(['a','b','c']);n=np.array([32,25,20]);x=np.tile(np.arange(32),(3,1))
m1=loss_mask(ids,n,.1,width=32);m2=loss_mask(ids,n,.2,width=32)
assert np.all(~m1|m2) and np.array_equal(m1,loss_mask(ids,n,.1,width=32))
deleted,nd=corrupt(x,n,m2,'deletion');assert np.array_equal(nd,n-m2.sum(1))
zero,_=corrupt(x,n,m2,'ZeroPad');assert np.all(zero[m2]==0)
markov=Markov().fit(x,n);filled=markov.impute(x,n,m2);assert np.array_equal(filled[~m2],x[~m2])
result=metrics(np.array([0,1,2]),np.array([0,1,2]),3);assert result['Accuracy']==100 and result['F1_macro']==100
reports.append({'check':'paired_masks_lengths_markov_metrics','status':'PASS'})
write_json(Path(__file__).resolve().parent.parent/'audit/software_selfcheck.json',{'scope':'synthetic_engineering_only','seconds':time.monotonic()-start,'checks':reports})
print(json.dumps({'checks':len(reports),'status':'PASS','seconds':time.monotonic()-start}))
