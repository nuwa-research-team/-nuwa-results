"""MLM comparison backends and explicitly labelled source repair / TFM approximation."""
import argparse, json, sys, time
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parent.parent/'.deps'))
import numpy as np
import torch
from torch.utils.data import DataLoader,TensorDataset
from core import seed_all,write_json,file_hash
PAD=1; UNK=3; MASK=4

def make_mlm(backend,vocab_size,tiny=False):
    from transformers import BertConfig,BertForMaskedLM,RobertaConfig,RobertaForMaskedLM,DebertaConfig,DebertaForMaskedLM
    params=dict(vocab_size=vocab_size,hidden_size=48 if tiny else 768,intermediate_size=96 if tiny else 3072,
        num_hidden_layers=1 if tiny else 6,num_attention_heads=4 if tiny else 12,max_position_embeddings=514,pad_token_id=PAD)
    if backend=='BERT': return BertForMaskedLM(BertConfig(**params))
    if backend=='Roberta': return RobertaForMaskedLM(RobertaConfig(**params,bos_token_id=0,eos_token_id=2,type_vocab_size=1))
    # Upstream Nuwa omitted relative_attention; HF default=False. Keep source repair distinct.
    relative=backend in ('Deberta','TFM-slot-approx')
    return DebertaForMaskedLM(DebertaConfig(**params,type_vocab_size=0,relative_attention=relative,pos_att_type=['p2c','c2p'] if relative else None))

def encode(x,lengths,values):
    mapping={int(v):i+5 for i,v in enumerate(values)}; result=np.full(x.shape,PAD,dtype=np.int64)
    for i,n in enumerate(lengths): result[i,:n]=[mapping.get(int(v),UNK) for v in x[i,:n]]
    return result

def noise(batch,mode,generator):
    valid=batch>=5; probability=torch.rand(batch.shape,generator=generator)
    selected=(probability<.15)&valid
    for row in range(len(batch)):
        if valid[row].any() and not selected[row].any(): selected[row,torch.where(valid[row])[0][0]]=True
    labels=batch.clone().masked_fill(~selected,-100); result=batch.clone()
    choice=torch.rand(batch.shape,generator=generator)
    if mode=='standard':
        result[selected&(choice<.8)]=MASK
        replacement=selected&(choice>=.8)&(choice<.9)
        result[replacement]=torch.randint(5,int(batch.max())+1,batch.shape,generator=generator)[replacement]
    elif mode=='slot_approx':
        # Explicit approximation: PAD slot instead of physical deletion, equal-length span masks.
        result[selected&(choice<.5)]=MASK
        result[selected&(choice>=.5)&(choice<.6)]=PAD
        span=selected&(choice>=.6)&(choice<.8)
        for row,col in span.nonzero().tolist():
            size=max(1,int(torch.poisson(torch.tensor(3.),generator=generator)))
            stop=min(col+size,int(valid[row].sum()))
            result[row,col:stop]=MASK; labels[row,col:stop]=batch[row,col:stop]
        for row,col in (selected&(choice>=.8)&(choice<.9)).nonzero().tolist():
            candidates=torch.where(valid[row])[0]; other=int(candidates[torch.randint(len(candidates),(1,),generator=generator)])
            result[row,col],result[row,other]=result[row,other].clone(),result[row,col].clone()
            labels[row,other]=batch[row,other]
    else: raise ValueError(mode)
    return result,labels

def impute(model,x,lengths,mask,values,device,batch_size=8):
    tokens=encode(x,lengths,values); tokens[mask]=MASK; result=x.copy()
    model.eval()
    with torch.inference_mode():
        for start in range(0,len(tokens),batch_size):
            batch=torch.as_tensor(tokens[start:start+batch_size],device=device)
            attention=torch.arange(x.shape[1],device=device)[None,:]<torch.as_tensor(lengths[start:start+batch_size],device=device)[:,None]
            logits=model(input_ids=batch,attention_mask=attention).logits
            pred=logits[:,:,5:].argmax(-1).cpu().numpy()
            subset=mask[start:start+batch_size]
            result[start:start+batch_size][subset]=np.asarray(values)[pred[subset]]
    return result

def train(args):
    seed_all(args.seed); data=np.load(args.dataset,allow_pickle=False)
    # Only train role reaches tokenizer/vocabulary or optimization.
    train_role=data['roles']=='train'; x=data['x'][train_role]; lengths=data['lengths'][train_role]
    values=np.unique(np.concatenate([row[:n] for row,n in zip(x,lengths)])); tokens=encode(x,lengths,values)
    out=Path(args.output); out.mkdir(parents=True,exist_ok=False)
    model=make_mlm(args.backend,len(values)+5).to(args.device)
    config=vars(args).copy(); config.update(vocabulary_values=values.tolist(),dataset_sha256=file_hash(args.dataset),
        rows=len(x),parameters=sum(p.numel() for p in model.parameters()),fit_role='train',
        paper_alignment=False,reason='Released source standard MLM differs from paper TFM; slot variant is explicitly approximate')
    write_json(out/'run.json',config); model.config.save_pretrained(out)
    write_json(out/'vocabulary.json',values.tolist())
    loader=DataLoader(TensorDataset(torch.from_numpy(tokens),torch.from_numpy(lengths)),batch_size=args.batch_size,shuffle=True,
        generator=torch.Generator().manual_seed(args.seed))
    optimizer=torch.optim.AdamW(model.parameters(),lr=1e-4,weight_decay=0)
    generator=torch.Generator().manual_seed(args.seed); steps=args.epochs*((len(loader)+args.accumulation-1)//args.accumulation)
    scheduler=torch.optim.lr_scheduler.LambdaLR(optimizer,lambda s:max(0,1-s/max(steps,1)))
    mode='slot_approx' if args.backend=='TFM-slot-approx' else 'standard'
    model.train(); optimizer.zero_grad(); start=time.monotonic()
    with (out/'epochs.jsonl').open('w',encoding='utf-8') as log:
        for epoch in range(args.epochs):
            losses=[]; epoch_start=time.monotonic()
            for step,(batch,n) in enumerate(loader):
                inputs,labels=noise(batch,mode,generator)
                attention=torch.arange(batch.shape[1])[None,:]<n[:,None]
                loss=model(input_ids=inputs.to(args.device),attention_mask=attention.to(args.device),labels=labels.to(args.device)).loss
                if not torch.isfinite(loss): raise RuntimeError('Nonfinite MLM loss')
                group_size=min(args.accumulation,len(loader)-(step//args.accumulation)*args.accumulation)
                (loss/group_size).backward(); losses.append(float(loss.detach()))
                if (step+1)%args.accumulation==0 or step+1==len(loader):
                    torch.nn.utils.clip_grad_norm_(model.parameters(),1); optimizer.step(); optimizer.zero_grad(); scheduler.step()
            log.write(json.dumps({'epoch':epoch+1,'loss':float(np.mean(losses)),'epoch_seconds':time.monotonic()-epoch_start})+'\n'); log.flush()
    model.save_pretrained(out,safe_serialization=True)
    write_json(out/'done.json',{'seconds':time.monotonic()-start,'data_sha256':config['dataset_sha256'],'fit_role':'train'})
    (out/'fit.done').write_text('complete\n')

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--dataset',required=True); p.add_argument('--output',required=True)
    p.add_argument('--backend',choices=['BERT','Roberta','Deberta','Nuwa-source-repair','TFM-slot-approx'],required=True)
    p.add_argument('--device',default='cuda'); p.add_argument('--seed',type=int,default=42); p.add_argument('--epochs',type=int,default=3)
    p.add_argument('--batch-size',type=int,default=8); p.add_argument('--accumulation',type=int,default=32)
    train(p.parse_args())
