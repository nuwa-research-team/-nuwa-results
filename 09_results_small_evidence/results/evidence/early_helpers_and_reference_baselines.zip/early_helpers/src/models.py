"""Transparent PyTorch reimplementations; Nuwa classifier hyperparameters unknown.
FS-Net topology follows WSPTTH/FS-Net model.py; not a bitwise TF1 port.
TST loads the pinned original implementation, with a PyTorch API adapter only.
"""
import importlib.util, math
from pathlib import Path
import torch
from torch import nn
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence

class CNN(nn.Module):
    def __init__(self,classes,**kw):
        super().__init__()
        self.net=nn.Sequential(nn.Conv1d(1,32,7,padding=3),nn.ReLU(),nn.MaxPool1d(2),
            nn.Conv1d(32,64,5,padding=2),nn.ReLU(),nn.AdaptiveAvgPool1d(8),nn.Flatten(),
            nn.Linear(512,128),nn.ReLU(),nn.Dropout(.2),nn.Linear(128,classes))
    def forward(self,x,lengths): return self.net(x[:,None,:])

class Recurrent(nn.Module):
    def __init__(self,classes,kind='GRU',hidden=128,**kw):
        super().__init__(); self.rnn=getattr(nn,kind)(1,hidden,2,batch_first=True,dropout=.2)
        self.head=nn.Linear(hidden,classes)
    def forward(self,x,lengths):
        p=pack_padded_sequence(x.unsqueeze(-1),lengths.cpu(),batch_first=True,enforce_sorted=False)
        _,h=self.rnn(p)
        if isinstance(h,tuple): h=h[0]
        return self.head(h[-1])

class SDAE(nn.Module):
    def __init__(self,classes,seq_len=512,**kw):
        super().__init__(); self.encoder=nn.Sequential(nn.Linear(seq_len,256),nn.ReLU(),nn.Linear(256,128),nn.ReLU())
        self.decoder=nn.Sequential(nn.Linear(128,256),nn.ReLU(),nn.Linear(256,seq_len)); self.head=nn.Linear(128,classes)
    def forward(self,x,lengths): return self.head(self.encoder(x))
    def denoising_loss(self,x,noise=.15):
        noisy=x.masked_fill(torch.rand_like(x)<noise,0); return (self.decoder(self.encoder(noisy))-x).square().mean()

class MultiBiGRU(nn.Module):
    def __init__(self,input_dim,hidden,layers=2,dropout=.2):
        super().__init__(); self.hidden=hidden
        self.layers=nn.ModuleList([nn.GRU(input_dim if i==0 else 2*hidden,hidden,bidirectional=True,batch_first=True) for i in range(layers)])
        self.initial=nn.ParameterList([nn.Parameter(torch.zeros(2,1,hidden)) for _ in range(layers)])
        self.dropout=nn.Dropout(dropout)
    def forward(self,x,lengths):
        states=[]; outputs=[]
        for rnn,h0 in zip(self.layers,self.initial):
            packed=pack_padded_sequence(self.dropout(x),lengths.cpu(),batch_first=True,enforce_sorted=False)
            result,h=rnn(packed,h0.expand(-1,x.shape[0],-1).contiguous())
            x,_=pad_packed_sequence(result,batch_first=True,total_length=x.shape[1]); outputs.append(x)
            states.append(h.transpose(0,1).reshape(x.shape[0],-1))
        return torch.cat(states,1),torch.cat(outputs,2)

class FSNet(nn.Module):
    def __init__(self,classes,hidden=128,layers=2,**kw):
        super().__init__(); width=2*hidden*layers
        # Signed IP lengths are adapted to nonnegative vocabulary IDs. Zero is pad.
        self.embedding=nn.Embedding(3202,16,padding_idx=0)
        self.encoder=MultiBiGRU(16,hidden,layers); self.decoder=MultiBiGRU(width,hidden,layers)
        self.reconstruct=nn.Sequential(nn.Linear(width,hidden),nn.SELU(),nn.Linear(hidden,3202))
        self.head=nn.Sequential(nn.Linear(2*width,2*hidden),nn.SELU(),nn.Dropout(.2),nn.Linear(2*hidden,classes))
    def features(self,x,lengths):
        ids=(x*1600).round().long().clamp(-1600,1600)+1601
        mask=torch.arange(x.shape[1],device=x.device)[None,:]<lengths[:,None]
        ids=ids.masked_fill(~mask,0)
        enc,_=self.encoder(self.embedding(ids),lengths)
        dec,out=self.decoder(enc[:,None,:].expand(-1,x.shape[1],-1),lengths)
        return self.head(torch.cat([enc,dec],1)),out,ids,mask
    def forward(self,x,lengths): return self.features(x,lengths)[0]
    def supervised_loss(self,x,lengths,y):
        logits,out,ids,mask=self.features(x,lengths)
        rec=nn.functional.cross_entropy(self.reconstruct(out)[mask],ids[mask])
        return nn.functional.cross_entropy(logits,y)+.5*rec

def make_tst(classes,seq_len=512,**kw):
    path=Path(__file__).resolve().parent.parent/'upstream/mvts_transformer/src/models/ts_transformer.py'
    if not path.exists(): raise FileNotFoundError('Clone pinned gzerveas/mvts_transformer first')
    spec=importlib.util.spec_from_file_location('nuwa_original_tst',path); module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    # PyTorch >=2 adds is_causal to TransformerEncoderLayer.forward.
    original=module.TransformerBatchNormEncoderLayer.forward
    def adapted(self,src,src_mask=None,src_key_padding_mask=None,is_causal=False):
        if is_causal: raise ValueError('Causal attention was not part of this TST adapter')
        return original(self,src,src_mask=src_mask,src_key_padding_mask=src_key_padding_mask)
    module.TransformerBatchNormEncoderLayer.forward=adapted
    base=module.TSTransformerEncoderClassiregressor(1,seq_len,64,8,3,256,num_classes=classes,dropout=.1,pos_encoding='fixed',activation='gelu',norm='BatchNorm')
    class Wrapper(nn.Module):
        def __init__(self): super().__init__(); self.base=base
        def forward(self,x,lengths):
            valid=torch.arange(x.shape[1],device=x.device)[None,:]<lengths[:,None]
            return self.base(x.unsqueeze(-1),valid)
    return Wrapper()

def make_classifier(name,classes,seq_len=512):
    if name=='CNN': return CNN(classes)
    if name in ('LSTM','GRU'): return Recurrent(classes,kind=name)
    if name=='SDAE': return SDAE(classes,seq_len=seq_len)
    if name=='FS-Net': return FSNet(classes)
    if name=='TST': return make_tst(classes,seq_len=seq_len)
    raise ValueError(name)
