"""Join explicit reproduction records to published cells without inventing F1 averaging.
Input JSON list fields: dataset, environment, classifier, imputer, loss_rate,
metric (Accuracy/F1_macro/F1_weighted/F1_micro), value_percent, run_id, scope,
protocol_alignment. Output preserves unmatched paper cells.
"""
import argparse,csv,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--results',required=True,type=Path);p.add_argument('--output',required=True,type=Path)
p.add_argument('--targets',type=Path,default=Path(__file__).with_name('paper_targets.csv'))
args=p.parse_args();results=json.loads(args.results.read_text(encoding='utf-8-sig'))
def key(r): return (r['dataset'],r['environment'],r['classifier'],r['imputer'],float(r['loss_rate']))
index={}
for r in results:
    if not 0<=float(r['value_percent'])<=100:raise ValueError('Metric must be percent, not fraction')
    if any(field not in r for field in ('run_id','scope','protocol_alignment')):raise ValueError('Missing provenance')
    index.setdefault(key(r),[]).append(r)
with args.targets.open(encoding='utf-8-sig',newline='') as f:targets=list(csv.DictReader(f))
out=[]
for row in targets:
    candidates=[r for r in index.get(key(row),[]) if r['metric']==row['metric'] or row['metric']=='F1' and r['metric'].startswith('F1_')]
    if not candidates:out.append(row);continue
    for r in candidates:
        result=dict(row);result['reproduced_value_percent']=r['value_percent'];result['run_id']=r['run_id']
        result['reproduction_metric']=r['metric']; result['scope']=r['scope']
        aligned=r['scope']=='paper_aligned' and r['protocol_alignment']=='verified'
        if row['metric']=='F1' and row['f1_averaging']=='unspecified':
            result['comparison_status']='F1_averaging_unresolved';result['delta_pp']=''
        elif not aligned:
            result['comparison_status']='protocol_or_scope_not_aligned';result['delta_pp']=''
        else:
            result['comparison_status']='comparable';result['delta_pp']=round(float(r['value_percent'])-float(row['paper_value_percent']),6)
        out.append(result)
fields=list(dict.fromkeys(field for r in out for field in r))
args.output.parent.mkdir(parents=True,exist_ok=True)
with args.output.open('w',encoding='utf-8-sig',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerows(out)
print(json.dumps({'paper_cells':len(targets),'output_rows':len(out),'comparable':sum(r['comparison_status']=='comparable' for r in out)}))
