import hashlib, json, random
from pathlib import Path
import numpy as np
import torch
from sklearn.metrics import accuracy_score, f1_score, confusion_matrix, recall_score

def seed_all(seed):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)

def write_json(path,value):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')

def file_hash(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for block in iter(lambda:f.read(8<<20),b''): h.update(block)
    return h.hexdigest()

def loss_mask(ids,lengths,ratio,seed=42,width=512):
    if ratio not in (0,.1,.2,.3): raise ValueError('Unregistered loss ratio')
    out=np.zeros((len(ids),width),dtype=bool)
    if ratio==0: return out
    for i,(identity,n) in enumerate(zip(ids,lengths)):
        n=int(n); digest=hashlib.sha256((str(seed)+':'+str(identity)).encode()).digest()
        rng=np.random.default_rng(int.from_bytes(digest[:8],'little'))
        # Same permutation for all ratios: masks are nested and reused across methods.
        out[i,rng.permutation(n)[:max(1,int(n*ratio))]]=True
    return out

def corrupt(x,lengths,mask,method):
    result=x.copy(); sizes=lengths.copy()
    if method=='clean':
        if mask.any(): raise ValueError('clean must use loss=0')
    elif method=='ZeroPad': result[mask]=0
    elif method=='deletion':
        result[:]=0
        for i,n in enumerate(lengths):
            values=x[i,:n][~mask[i,:n]]; result[i,:len(values)]=values; sizes[i]=len(values)
    else: raise ValueError(method)
    return result,sizes

def metrics(y,pred,classes):
    labels=list(range(classes))
    return {'Accuracy':100*accuracy_score(y,pred),'F1_macro':100*f1_score(y,pred,labels=labels,average='macro',zero_division=0),
        'F1_weighted':100*f1_score(y,pred,labels=labels,average='weighted',zero_division=0),
        'F1_micro':100*f1_score(y,pred,labels=labels,average='micro',zero_division=0),
        'recall_per_class':(100*recall_score(y,pred,labels=labels,average=None,zero_division=0)).tolist(),
        'support':np.bincount(y,minlength=classes).tolist(),'confusion_matrix':confusion_matrix(y,pred,labels=labels).tolist()}

class Markov:
    """First-order transition bridge. Declared reimplementation, authors' code missing."""
    def fit(self,x,lengths):
        self.values=np.unique(np.concatenate([row[:n] for row,n in zip(x,lengths)])); k=len(self.values)
        self.prior=np.full(k,1e-6); self.counts=np.full((k,k),1e-6,dtype=np.float32)
        for row,n in zip(x,lengths):
            indices=np.searchsorted(self.values,row[:n]); np.add.at(self.prior,indices,1)
            np.add.at(self.counts,(indices[:-1],indices[1:]),1)
        self.prior/=self.prior.sum(); self.counts/=self.counts.sum(1,keepdims=True); return self
    def impute(self,x,lengths,mask):
        result=x.copy()
        for i,n in enumerate(lengths):
            for j in np.flatnonzero(mask[i,:n]):
                score=self.prior.copy()
                if j>0 and result[i,j-1] in self.values:
                    score=self.counts[np.searchsorted(self.values,result[i,j-1])].copy()
                if j+1<n and not mask[i,j+1] and x[i,j+1] in self.values:
                    score*=self.counts[:,np.searchsorted(self.values,x[i,j+1])]
                result[i,j]=self.values[score.argmax()]
        return result
