"""Transcribe published cells, preserving header names and source provenance."""
import csv, json, re
from pathlib import Path
root=Path(__file__).resolve().parent.parent
text=(root/'papers/supplementary_text.txt').read_text(encoding='utf-8-sig')
settings={
 'VIII':('d1','simulated','baseline'), 'IX':('d2','simulated','baseline'),
 'X':('d3','simulated','baseline'), 'XI':('d4','simulated','baseline'),
 'XII':('d1','real_replay','baseline'), 'XIII':('d3','real_replay','baseline'), 'XIV':('d4','real_replay','baseline'),
 'XV':('d1','simulated','TFI'), 'XVI':('d2','simulated','TFI'), 'XVII':('d3','simulated','TFI'), 'XVIII':('d4','simulated','TFI'),
 'XIX':('d1','real_replay','TFI'), 'XX':('d3','real_replay','TFI'), 'XXI':('d4','real_replay','TFI'),
 'XXXI':('d1','simulated','sota'), 'XXXII':('d2','simulated','sota'),
 'XXXIII':('d3','simulated','sota'), 'XXXIV':('d4','simulated','sota')}
rows=[]; page=0; table=None; counts={}
def add(dataset,env,model,method,rate,metric,value,source,table,page,status):
    rows.append(dict(dataset=dataset,environment=env,classifier=model,imputer=method,loss_rate=rate,
        metric=metric,paper_value_percent=value,f1_averaging='unspecified' if metric=='F1' else 'na',
        source=source,table=table,page=page,verification=status,reproduced_value_percent='',delta_pp='',run_id='',comparison_status='not_run'))
for line in text.splitlines():
    p=re.match(r'=== PAGE (\d+) ===',line)
    if p: page=int(p[1])
    t=re.match(r'^TABLE ([IVXL]+)$',line.strip())
    if t: table=t[1]; counts[table]=0
    if table not in settings: continue
    match=re.match(r'^(CNN|LSTM|GRU|TST|SDAE|FS-Net)(?:\+TFI)?\s',line)
    if not match: continue
    model=match[1]; dataset,env,kind=settings[table]
    cleaned=re.sub(r'\([^)]*\)','',line)
    values=re.findall(r'(\d+(?:\.\d+)?)\s*%',cleaned)
    expected=8 if kind=='baseline' else 10 if kind=='sota' else 6
    if len(values)!=expected: raise ValueError((table,model,len(values),expected))
    n=counts[table]; counts[table]+=1
    if kind=='sota':
        rate=[.1,.2,.3][n//6]
        for j,method in enumerate(['ZeroPad','Markov','BERT','Roberta','Deberta']):
            for k,metric in enumerate(['Accuracy','F1']):
                add(dataset,env,model,method,rate,metric,values[2*j+k],'supplementary',table,page,'text_extracted_header_preserved_visual_review_pending')
    else:
        rates=[0,.1,.2,.3] if kind=='baseline' else [.1,.2,.3]
        for j,rate in enumerate(rates):
            for k,metric in enumerate(['Accuracy','F1']):
                add(dataset,env,model,'clean' if rate==0 else 'deletion' if kind=='baseline' else 'TFI',rate,metric,values[2*j+k],'supplementary',table,page,'text_extracted_visual_review_pending')
for table in settings:
    assert counts[table]==(18 if settings[table][2]=='sota' else 6),(table,counts[table])
# Main paper II and IV were visually checked, PDF pages 5 and 6.
main={
'II':[[99.86,99.86,70.46,70.48,44.01,42.47,30.58,25.90],[98.83,98.83,57.14,56.32,38.69,37.32,30.23,27.73],[99.22,99.22,57.14,56.56,38.90,37.38,29.25,27.27],[99.20,99.20,84.30,84.64,63.09,63.99,40.32,37.90],[94.84,94.84,52.93,52.94,38.47,38.47,32.64,32.09],[99.78,99.78,96.30,96.32,85.10,85.34,70.43,70.78]],
'IV':[[98.15,98.15,92.76,92.68,84.08,83.73],[94.91,94.87,88.08,87.79,81.59,83.99],[95.05,95.02,87.35,87.06,79.66,78.94],[98.49,98.48,95.25,95.23,83.90,83.45],[91.83,91.77,85.93,85.63,78.70,78.02],[99.49,99.49,98.79,98.78,95.34,95.43]]}
for table,models in main.items():
    for model,values in zip(['CNN','LSTM','GRU','TST','SDAE','FS-Net'],models):
        for j,rate in enumerate([0,.1,.2,.3] if table=='II' else [.1,.2,.3]):
            for k,metric in enumerate(['Accuracy','F1']):
                add('d2','real_replay',model,'clean' if rate==0 else 'deletion' if table=='II' else 'TFI',rate,metric,values[2*j+k],'main',table,5 if table=='II' else 6,'visually_checked')
dest=root/'shared/paper_targets.csv'
with dest.open('w',newline='',encoding='utf-8-sig') as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
print(json.dumps({'cells':len(rows),'tables':len(settings)+2,'output':str(dest)}))
