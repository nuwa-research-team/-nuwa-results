# -*- coding: utf-8 -*-
"""Freeze the one-shot revision protocol and hash-chain before any fit."""
import hashlib
import json
import subprocess
from pathlib import Path

R = Path('/data1/lhy/nuwa')


def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()


def git_head(p):
    try:
        return subprocess.run(['git', '-C', str(p), 'rev-parse', 'HEAD'],
                              capture_output=True, text=True, timeout=20).stdout.strip() or None
    except Exception:
        return None


proto = {
    'protocol': 'one-shot bounded revision of TST / FS-Net / SDAE',
    'scope': 'only the two authorised experiments; no extra experiments',
    'seed': 42,
    'data': {'root': str(R / 'work/d4_aligned/raw.pkl'), 'sha256': sha(R / 'work/d4_aligned/raw.pkl'),
             'roles': 'same train/val/test as engineering table; test never used for selection'},
    'common': {'supervised_epochs_max': 15, 'patience': 4, 'selection': 'val accuracy',
               'batch': 256, 'lr': 1e-3, 'input_scale': 1 / 1600.0,
               'grad_clip': 5.0, 'optimizer': 'Adam'},
    'models': {
        'tst': {'implementation': 'pinned gzerveas/mvts_transformer TSTransformerEncoderClassiregressor',
                'adapter': 'PyTorch>=2 is_causal signature only; no architecture change',
                'd_model': 64, 'heads': 8, 'layers': 3, 'dim_feedforward': 256,
                'dropout': 0.1, 'pos_encoding': 'fixed', 'activation': 'gelu', 'norm': 'BatchNorm'},
        'fsnet': {'implementation': 'WSPTTH/FS-Net topology (encoder/decoder MultiBiGRU + reconstruction)',
                  'hidden': 128, 'layers': 2, 'vocab': 3202, 'reconstruction_weight': 0.5,
                  'loss': 'CE + 0.5 * CE(reconstruct, ids)'},
        'sdae': {'implementation': 'greedy layer-wise denoising auto-encoder',
                 'stage1': 'Linear(512->256)+ReLU, decoder 256->512, mask noise 0.15, MSE, <=5 epochs',
                 'stage2': 'Linear(256->128)+ReLU, decoder 128->256 on frozen layer1, noise 0.15, MSE, <=5 epochs',
                 'stage3': 'head Linear(128->classes), CE, <=15 epochs, patience 4'},
    },
    'artifacts': {'dir': str(R / 'repaired'), 'eval_dir': str(R / 'work/repaired_eval_20261110'),
                  'old_artifacts_preserved': True, 'no_overwrite': True},
    'declaration': 'declared migration / mechanism reproduction; original hyper-parameters unknown; not bit-level original',
}

for key, rel in [('train_repaired', 'repaired/train_repaired.py'),
                 ('models_repaired', 'repaired/models_repaired.py'),
                 ('eval_repaired', 'repaired/eval_repaired.py'),
                 ('tst_upstream', 'upstream/mvts_transformer/src/models/ts_transformer.py')]:
    p = R / rel
    proto.setdefault('hashes', {})[key] = sha(p) if p.exists() else None

proto['hashes']['tst_upstream_commit'] = git_head(R / 'upstream/mvts_transformer')
proto['hashes']['fsnet_upstream_commit'] = git_head(R / 'upstream/FS-Net')

out = R / 'repaired/protocol_repaired_20261110.json'
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(json.dumps(proto, indent=2))
print(json.dumps(proto['hashes'], indent=2))
print('written', out)
