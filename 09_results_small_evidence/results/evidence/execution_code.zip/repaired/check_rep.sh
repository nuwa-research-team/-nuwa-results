#!/usr/bin/env bash
cd /data1/lhy/nuwa
./venv/bin/python - <<'PY'
import json, glob
for f in sorted(glob.glob('repaired/repaired_*.json')):
    d = json.load(open(f))
    print(d['model'], 'val_acc=%.4f' % d['val_acc_best'], 'epochs=%d' % d['epochs_run'],
          'train_s=%.1f' % d['train_seconds'], d.get('stage_accounting', {}))
PY
echo "--- fsnet ---"
tail -2 repaired/logs/run_fsnet.log
echo "--- sdae ---"
tail -2 repaired/logs/run_sdae.log 2>/dev/null || echo "not started"
