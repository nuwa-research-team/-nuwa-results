#!/usr/bin/env bash
# Standalone 66-cell evaluation wrapper (no training loop, no retry of fits).
set -uo pipefail
cd /data1/lhy/nuwa
WANT=GPU-ff6cdf9c-b34e-7a0d-8666-8453e842e779
OUTDIR=work/repaired_eval_20261110
mkdir -p repaired/logs

if [ -e "$OUTDIR" ]; then
  echo "output already exists: $OUTDIR"; exit 4
fi

check() {
  local uuid used
  uuid=$(nvidia-smi -i 1 --query-gpu=uuid --format=csv,noheader 2>/dev/null | tr -d ' ')
  used=$(nvidia-smi -i 1 --query-gpu=memory.used --format=csv,noheader,nounits 2>/dev/null | tr -d ' ')
  echo "$(date -Is) gpu1 uuid=$uuid used=${used}MiB"
  [ "$uuid" = "$WANT" ] && [ -n "$used" ] && [ "$used" -lt 2048 ]
}

ok=0
while [ $ok -lt 3 ]; do
  if check; then ok=$((ok+1)); else ok=0; fi
  sleep 40
done
check || { echo "pre-launch check failed"; exit 3; }

echo "$(date -Is) eval start"
CUDA_VISIBLE_DEVICES=1 ./venv/bin/python repaired/eval_repaired.py \
  --out "$OUTDIR" --device cuda --batch 512 2>&1 | tee repaired/logs/eval_repaired.log
rc=${PIPESTATUS[0]}
echo "$(date -Is) eval rc=$rc"
[ $rc -eq 0 ] || exit 5
[ -f "$OUTDIR/evaluation.done" ] || { echo "no evaluation.done"; exit 6; }
echo "$(date -Is) eval finished"
