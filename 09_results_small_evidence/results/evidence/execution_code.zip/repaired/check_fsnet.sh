#!/usr/bin/env bash
cd /data1/lhy/nuwa
echo "=== procs ==="
ps -u lhy -o pid,etime,pcpu,pmem,args | awk '/train_repaired/ && !/awk/ {print substr($0,1,150)}'
echo "=== gpu ==="
nvidia-smi --query-gpu=index,memory.used,utilization.gpu --format=csv,noheader
nvidia-smi --query-compute-apps=pid,used_memory --format=csv
echo "=== logs ==="
tail -3 repaired/logs/run_fsnet.log
echo "=== runner ==="
tail -3 repaired/logs/run_all.log
