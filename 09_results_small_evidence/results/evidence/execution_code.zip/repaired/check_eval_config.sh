#!/usr/bin/env bash
# Py3.8 config-construction check for eval_repaired.py (no directory created).
set -euo pipefail
cd /data1/lhy/nuwa
./venv/bin/python - <<'PY'
import hashlib, json
from pathlib import Path
ROOT = Path('/data1/lhy/nuwa')
PE = ROOT / 'work/paired_eval_v2_20261110'

def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()

cfg = {
    'checkpoint_sha256': {n: sha(ROOT / 'repaired' / f'repaired_{n}.pt')
                          for n in ('tst', 'fsnet', 'sdae')},
    'source_sha256': {'train': sha(ROOT / 'repaired/train_repaired.py'),
                      'models': sha(ROOT / 'repaired/models_repaired.py'),
                      'eval': sha(ROOT / 'repaired/eval_repaired.py')},
    'protocol_sha256': sha(ROOT / 'repaired/protocol_repaired_20261110.json'),
    'paired_source_sha256': {**{p.name: sha(p) for p in sorted(PE.glob('mask_*.npz'))},
                             **{p.name: sha(p) for p in sorted(PE.glob('*_imputed_*.npz'))}},
}
s = json.dumps(cfg, indent=2)
print('config ok, keys:', list(cfg))
print('paired files:', len(cfg['paired_source_sha256']))
PY
echo "--- imports ---"
./venv/bin/python -c "import sys; sys.path.insert(0,'repaired'); import eval_repaired; print('eval import ok')"
