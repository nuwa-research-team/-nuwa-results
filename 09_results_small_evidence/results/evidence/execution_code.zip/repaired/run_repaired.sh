#!/usr/bin/env bash
# Sequential repaired-model fits on GPU1 after three idle checks.
# Any non-zero training exit stops the queue (no silent continuation).
set -uo pipefail
cd /data1/lhy/nuwa
WANT=GPU-ff6cdf9c-b34e-7a0d-8666-8453e842e779
mkdir -p repaired/logs logs
COUNT=repaired/logs/launch_count.txt
touch "$COUNT"

check() {
  local uuid used
  uuid=$(nvidia-smi -i 1 --query-gpu=uuid --format=csv,noheader 2>/dev/null | tr -d ' ')
  used=$(nvidia-smi -i 1 --query-gpu=memory.used --format=csv,noheader,nounits 2>/dev/null | tr -d ' ')
  echo "$(date -Is) gpu1 uuid=$uuid used=${used}MiB"
  [ "$uuid" = "$WANT" ] && [ -n "$used" ] && [ "$used" -lt 2048 ]
}

ok=0
while [ $ok -lt 3 ]; do
  if check; then ok=$((ok+1)); else ok=0; fi
  sleep 40
done
check || { echo "pre-launch check failed"; exit 3; }

for M in tst fsnet sdae; do
  echo "$(date -Is) === $M start ===" | tee -a "$COUNT"
  CUDA_VISIBLE_DEVICES=1 ./venv/bin/python repaired/train_repaired.py \
    --model "$M" --gpu 1 --epochs 15 --patience 4 >> "repaired/logs/run_${M}.log" 2>&1
  rc=$?
  echo "$(date -Is) $M rc=$rc" | tee -a "$COUNT"
  if [ $rc -ne 0 ]; then
    echo "$(date -Is) STOP: $M failed with rc=$rc; queue halted" | tee -a "$COUNT"
    exit 4
  fi
  [ -f "repaired/repaired_${M}.pt" ] || { echo "STOP: $M produced no checkpoint"; exit 5; }
done

echo "$(date -Is) === eval 66 cells ===" | tee -a "$COUNT"
CUDA_VISIBLE_DEVICES=1 ./venv/bin/python repaired/eval_repaired.py \
  --out work/repaired_eval_20261110 --device cuda --batch 512 2>&1 \
  | tee repaired/logs/eval_repaired.log | tail -5
rc=${PIPESTATUS[0]}
echo "$(date -Is) eval rc=$rc" | tee -a "$COUNT"
[ $rc -eq 0 ] || exit 6
