# -*- coding: utf-8 -*-
"""Build the repaired-model tables (3 models x 22 conditions)."""
import json
from pathlib import Path

OUT = Path('/data1/lhy/nuwa/work/repaired_eval_20261110')
m = json.load(open(OUT / 'metrics.json'))
cells = {(r['classifier'], r['method'], r['loss_percent']): r for r in m}
methods = ['deletion', 'ZeroPad', 'Markov', 'tfi', 'bert', 'roberta', 'deberta']
clfs = ['tst', 'fsnet', 'sdae']
lines = ["# Repaired classifiers (declared migration) — 66 paired cells", "",
         "## Robustness (Acc / macro-F1 %)", "",
         "| model | clean | loss10 | loss20 | loss30 |", "|---|---|---|---|---|"]
for c in clfs:
    r = cells[(c, 'clean', 0)]
    row = [f"{r['accuracy']*100:.2f}/{r['f1_macro']*100:.2f}"]
    for rate in (10, 20, 30):
        r = cells[(c, 'deletion', rate)]
        row.append(f"{r['accuracy']*100:.2f}/{r['f1_macro']*100:.2f}")
    lines.append(f"| {c} | " + " | ".join(row) + " |")
for rate in (10, 20, 30):
    lines += ["", f"## Imputation SOTA at {rate}% loss (Acc / macro-F1 %)", "",
              "| model | " + " | ".join(methods) + " |", "|---" * (len(methods) + 1) + "|"]
    for c in clfs:
        lines.append(f"| {c} | " + " | ".join(
            f"{cells[(c, me, rate)]['accuracy']*100:.2f}/{cells[(c, me, rate)]['f1_macro']*100:.2f}"
            for me in methods) + " |")
text = "\n".join(lines) + "\n"
(OUT / 'TABLES.md').write_text(text)
print(text)
