#!/usr/bin/env bash
cd /data1/lhy/nuwa
echo "=== start lines ==="
grep -n "start fsnet" repaired/logs/run_fsnet.log
grep -c "start fsnet" repaired/logs/run_fsnet.log
echo "=== process start ==="
ps -o pid,lstart,etime,cmd -p 63423 2>/dev/null | cut -c1-120
echo "=== full fsnet log ==="
cat repaired/logs/run_fsnet.log
