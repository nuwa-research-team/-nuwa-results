# -*- coding: utf-8 -*-
"""Traffic Feature Masking (TFM) strategies.

IMPORTANT DISCLOSURE
--------------------
* mode="paper_tfm_approx"  : our approximation of the paper's TFM (Sec. IV-C):
  per-sample corruption drawn from {random mask, Poisson span mask, random
  swap of two positions}, with 15% of tokens selected and BERT-style
  80/10/10 inside the selected set. The paper reports L = L_mask + L_span +
  L_RR but does not specify their weights; we sample one family per sample.
  This is NOT a verified reimplementation of the authors' private code.
* mode="mlm_80_10_10"      : plain BERT MLM (80% [MASK] / 10% random /
  10% unchanged). Earlier revisions of this file wrongly called it "paper".
* mode="released_source_repair" : repair of the released TFM.py intent
  (mask .5 / delete .1 / infill .2 / permute .1). The released file is
  syntactically broken, so this cannot be called "original execution".
"""
import torch


class TFMCollator:
    def __init__(self, tokenizer, mlm_probability=0.15, mode="paper_tfm_approx",
                 poisson_lambda=3.0):
        self.tokenizer = tokenizer
        self.mlm_probability = mlm_probability
        self.mode = mode
        self.poisson_lambda = poisson_lambda
        self.mask_id = tokenizer.mask_token_id
        self.pad_id = tokenizer.pad_token_id
        self.vocab_size = len(tokenizer)

    # ---------- helpers ----------
    def _special_mask(self, features, input_ids):
        if "special_tokens_mask" in features[0]:
            return torch.stack([f["special_tokens_mask"] for f in features]).bool()
        sm = [self.tokenizer.get_special_tokens_mask(ids.tolist(),
                                                     already_has_special_tokens=True)
              for ids in input_ids]
        return torch.tensor(sm, dtype=torch.bool)

    def _select(self, shape, special):
        prob = torch.full(shape, self.mlm_probability)
        prob.masked_fill_(special, 0.0)
        return torch.bernoulli(prob).bool()

    def _span_positions(self, special_row, length):
        """Poisson-lambda span starting at a random valid position."""
        pos = torch.randint(0, max(1, length - 1), (1,)).item()
        span = max(1, int(torch.poisson(torch.tensor(float(self.poisson_lambda))).item()))
        idx = torch.zeros_like(special_row)
        idx[pos: min(length, pos + span)] = True
        return idx & ~special_row

    # ---------- collator ----------
    def __call__(self, features):
        # dynamic padding to the longest sequence in this batch (cap handled upstream)
        B = len(features)
        maxlen = max(len(f["input_ids"]) for f in features)
        input_ids = torch.full((B, maxlen), self.pad_id, dtype=torch.long)
        special = torch.ones(B, maxlen, dtype=torch.bool)
        for i, f in enumerate(features):
            ids = f["input_ids"]
            n = len(ids)
            input_ids[i, :n] = ids
            sm = f.get("special_tokens_mask")
            if sm is None:
                sm = self.tokenizer.get_special_tokens_mask(
                    ids.tolist(), already_has_special_tokens=True)
            special[i, :n] = torch.tensor(sm, dtype=torch.bool)
        labels = input_ids.clone()
        B, L = input_ids.shape

        if self.mode == "mlm_80_10_10":
            masked = self._select((B, L), special)
            labels[~masked] = -100
            r = torch.rand(B, L)
            input_ids[masked & (r < 0.8)] = self.mask_id
            rand_pos = masked & (r >= 0.8) & (r < 0.9)
            rand_tokens = torch.randint(0, self.vocab_size, (B, L))
            input_ids[rand_pos] = rand_tokens[rand_pos]

        elif self.mode == "released_source_repair":
            masked = self._select((B, L), special)
            labels[~masked] = -100
            m = torch.bernoulli(torch.full((B, L), 0.50)).bool() & masked
            d = torch.bernoulli(torch.full((B, L), 0.10)).bool() & masked & ~m
            i = torch.bernoulli(torch.full((B, L), 0.20)).bool() & masked & ~m & ~d
            input_ids[m] = self.mask_id
            input_ids[d] = self.pad_id
            input_ids[i] = self.mask_id

        else:  # paper_tfm_approx
            choice = torch.randint(0, 3, (B,))
            for b in range(B):
                if choice[b] == 1:  # Poisson span mask
                    pos = self._span_positions(special[b], L)
                else:
                    pos = self._select((L,), special[b])
                if choice[b] == 2:  # random swap (out-of-order simulation)
                    valid = (~special[b]).nonzero().flatten()
                    if len(valid) >= 2:
                        a, c = valid[torch.randperm(len(valid))[:2]]
                        tmp = input_ids[b, a].clone()
                        input_ids[b, a] = input_ids[b, c]
                        input_ids[b, c] = tmp
                        labels[b, ~(pos | (torch.arange(L) == a) | (torch.arange(L) == c))] = -100
                        continue
                labels[b, ~pos] = -100
                r = torch.rand(L)
                input_ids[b, pos & (r < 0.8)] = self.mask_id
                rand_pos = pos & (r >= 0.8) & (r < 0.9)
                if rand_pos.any():
                    input_ids[b, rand_pos] = torch.randint(0, self.vocab_size, (int(rand_pos.sum()),))

        return {
            "input_ids": input_ids,
            "attention_mask": (input_ids != self.pad_id).long(),
            "labels": labels,
        }
