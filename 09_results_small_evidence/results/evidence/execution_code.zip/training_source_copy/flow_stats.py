# -*- coding: utf-8 -*-
"""Session-count statistics from the cached flow pickle."""
import pickle
import sys
from collections import Counter
from pathlib import Path

cache = pickle.load(open(sys.argv[1], "rb"))
rows = []
for path, seqs in cache.items():
    cls = Path(path).stem
    lens = [len(s) for s in seqs]
    rows.append((Path(path).parent.name, cls, len(lens),
                 sum(1 for n in lens if n >= 10),
                 sum(1 for n in lens if n >= 15),
                 sum(1 for n in lens if n >= 20),
                 sum(1 for n in lens if n >= 30),
                 max(lens) if lens else 0))

print(f"{'split':8s} {'class':16s} {'flows':>7s} {'>=10':>7s} {'>=15':>7s} {'>=20':>7s} {'>=30':>7s} {'max':>6s}")
tot = Counter()
for r in rows:
    print(f"{r[0]:8s} {r[1]:16s} {r[2]:7d} {r[3]:7d} {r[4]:7d} {r[5]:7d} {r[6]:7d} {r[7]:6d}")
    for i in (2, 3, 4, 5, 6):
        tot[i] += r[i]
print("-" * 70)
print(f"{'TOTAL':25s} {tot[2]:7d} {tot[3]:7d} {tot[4]:7d} {tot[5]:7d} {tot[6]:7d}")
