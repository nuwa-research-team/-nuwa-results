﻿# -*- coding: utf-8 -*-
"""Train / evaluate the downstream classifiers under simulated packet loss.

Per model: train once on clean training data (early stop on a held-out
validation split carved from train), then evaluate on the SAME test flows
under {clean, ZeroPad(loss), TFI-imputed(loss)}.

Outputs metrics.json, table.md, predictions/*.npz and a confusion matrix per
condition. F1 is reported as macro / weighted / micro because the paper does
not state its averaging.
"""
import argparse
import json
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score
from torch.utils.data import DataLoader, TensorDataset

import models


def metrics(y, p, n_cls):
    return {
        "acc": round(float(accuracy_score(y, p)), 5),
        "f1_macro": round(float(f1_score(y, p, average="macro", zero_division=0)), 5),
        "f1_weighted": round(float(f1_score(y, p, average="weighted", zero_division=0)), 5),
        "f1_micro": round(float(f1_score(y, p, average="micro", zero_division=0)), 5),
        "support": np.bincount(y, minlength=n_cls).tolist(),
        "pred_support": np.bincount(p, minlength=n_cls).tolist(),
    }


def run_epoch(model, loader, dev, opt=None, lossf=None):
    train = opt is not None
    if lossf is None:
        lossf = nn.CrossEntropyLoss()
    model.train(train)
    ys, ps, tot, n = [], [], 0.0, 0
    for xb, yb in loader:
        xb, yb = xb.to(dev), yb.to(dev)
        out = model(xb)
        loss = lossf(out, yb)
        if train:
            opt.zero_grad()
            loss.backward()
            opt.step()
        tot += float(loss) * len(yb)
        n += len(yb)
        ps.append(out.argmax(1).detach().cpu().numpy())
        ys.append(yb.cpu().numpy())
    return tot / max(n, 1), np.concatenate(ys), np.concatenate(ps)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--losses", default="", help="dir with loss<rr>.npz files")
    ap.add_argument("--ratios", default="0.1,0.2,0.3")
    ap.add_argument("--models", default="cnn,lstm,gru,tst,sdae,fsnet")
    ap.add_argument("--epochs", type=int, default=30)
    ap.add_argument("--patience", type=int, default=5)
    ap.add_argument("--batch", type=int, default=256)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    dev = "cuda" if torch.cuda.is_available() else "cpu"
    d = np.load(Path(args.data) / "train.npz")
    Xtr, ytr = d["X"], d["y"]
    t = np.load(Path(args.data) / "test.npz")
    Xte, yte = t["X"], t["y"]
    vp = Path(args.data) / "val.npz"
    if vp.exists():
        v = np.load(vp)
        Xva, yva = v["X"], v["y"]
    else:
        Xva, yva = Xtr[: max(1, len(Xtr) // 10)], ytr[: max(1, len(Xtr) // 10)]
    n_cls = int(max(ytr.max(), yte.max())) + 1

    Xte_list = [("clean", Xte)]
    for r in [float(x) for x in args.ratios.split(",") if x]:
        p = Path(args.losses) / f"loss{str(r).replace('.', '')}.npz"
        if not p.exists():
            print("missing", p)
            continue
        d2 = np.load(p)
        assert len(d2["X_mask"]) == len(Xte), "loss file/test mismatch"
        Xte_list.append((f"zero_{int(r*100)}", d2["X_mask"]))
        Xte_list.append((f"tfi_{int(r*100)}", d2["X_impute"]))

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    (out / "predictions").mkdir(exist_ok=True)
    results = []

    for name in args.models.split(","):
        torch.manual_seed(args.seed)
        np.random.seed(args.seed)
        model = models.build(name, n_cls).to(dev)
        opt = torch.optim.Adam(model.parameters(), lr=args.lr)
        lossf = nn.CrossEntropyLoss()
        dl_tr = DataLoader(TensorDataset(torch.tensor(Xtr).unsqueeze(1),
                                         torch.tensor(ytr)),
                           batch_size=args.batch, shuffle=True, drop_last=True)
        dl_va = DataLoader(TensorDataset(torch.tensor(Xva).unsqueeze(1),
                                         torch.tensor(yva)), batch_size=512)

        t0 = time.time()
        best, best_state, bad = 1e9, None, 0
        hist = []
        for ep in range(args.epochs):
            te0 = time.time()
            tr_loss, _, _ = run_epoch(model, dl_tr, dev, opt, lossf)
            va_loss, _, va_pred = run_epoch(model, dl_va, dev)
            va_acc = accuracy_score(yva, va_pred)
            hist.append({"epoch": ep, "train_loss": round(tr_loss, 4),
                         "val_loss": round(va_loss, 4), "val_acc": round(float(va_acc), 4),
                         "seconds": round(time.time() - te0, 1)})
            if va_loss < best - 1e-5:
                best, bad = va_loss, 0
                best_state = {k: v.detach().clone() for k, v in model.state_dict().items()}
            else:
                bad += 1
                if bad >= args.patience:
                    break
        if best_state is not None:
            model.load_state_dict(best_state)

        res = {"model": name,
               "params": int(sum(p.numel() for p in model.parameters())),
               "train_seconds": round(time.time() - t0, 1),
               "epochs_run": len(hist),
               "seconds_per_epoch": round(np.mean([h["seconds"] for h in hist]), 2),
               "history": hist,
               "conditions": {}}
        for tag, Xte_c in Xte_list:
            dl = DataLoader(TensorDataset(torch.tensor(Xte_c).unsqueeze(1),
                                          torch.tensor(yte)), batch_size=512)
            _, yt, yp = run_epoch(model, dl, dev)
            res["conditions"][tag] = metrics(yt, yp, n_cls)
            res["conditions"][tag]["confusion"] = confusion_matrix(
                yt, yp, labels=list(range(n_cls))).tolist()
            np.savez_compressed(out / "predictions" / f"{name}_{tag}.npz",
                                y=yt, pred=yp)
        results.append(res)
        print(json.dumps({k: v for k, v in res.items() if k != "history"})[:500], flush=True)

    json.dump(results, open(out / "metrics.json", "w"), indent=2)

    conds = [c for c, _ in Xte_list]
    lines = ["| model | " + " | ".join(conds) + " |",
             "|---" * (len(conds) + 1) + "|"]
    for r in results:
        cells = []
        for c in conds:
            m = r["conditions"][c]
            cells.append(f'{m["acc"]*100:.2f}/{m["f1_macro"]*100:.2f}')
        lines.append(f'| {r["model"]} | ' + " | ".join(cells) + " |")
    table = "\n".join(lines)
    (out / "table.md").write_text(table + "\n")
    print(table)


if __name__ == "__main__":
    main()
