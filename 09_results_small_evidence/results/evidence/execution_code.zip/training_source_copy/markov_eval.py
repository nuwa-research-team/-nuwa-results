# -*- coding: utf-8 -*-
"""First-order Markov imputation baseline evaluated with a trained checkpoint.

Transitions P(next_len | prev_len) are estimated on TRAIN sessions only.
Missing positions use the same random mask as train_fast.SeqDS (seed+i).
"""
import argparse
import json
import pickle
from collections import defaultdict
from pathlib import Path

import numpy as np
import torch
from sklearn.metrics import accuracy_score, f1_score

import models
from train_fast import SeqDS, bucketed_loader, collate  # noqa: F401


def build_markov(seqs, idx):
    trans = defaultdict(lambda: defaultdict(int))
    for i in idx:
        s = seqs[i]
        for a, b in zip(s[:-1], s[1:]):
            trans[a][b] += 1
    table = {k: max(v.items(), key=lambda kv: kv[1])[0] for k, v in trans.items()}
    return table


def fill_markov(seq, pos, table):
    out = list(seq)
    for p in sorted(pos):
        prev = out[p - 1] if p > 0 else 0
        out[p] = table.get(prev, prev)
    return out


def masked_positions(i, L, ratio, seed):
    rng = np.random.default_rng(seed + i)
    n = max(1, int(round(L * ratio)))
    return rng.choice(L, size=n, replace=False)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--ckpt_dir", required=True)
    ap.add_argument("--models", default="cnn,gru")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    d = pickle.load(open(Path(args.data) / "raw.pkl", "rb"))
    seqs, y, labels = d["seqs"], d["y"], d["labels"]
    n_cls = len(labels)
    te = d["split"]["test"]
    table = build_markov(seqs, d["split"]["train"])
    print("markov states:", len(table), flush=True)

    res = {}
    for name in args.models.split(","):
        ck = torch.load(Path(args.ckpt_dir) / f"{name}.pt", map_location=dev)
        model = models.build(name, n_cls).to(dev)
        model.load_state_dict(ck["state"])
        model.eval()
        res[name] = {}
        for r in (0.1, 0.2, 0.3):
            rows = []
            for i in te:
                s = seqs[i]
                L = len(s)
                pos = masked_positions(i, L, r, 42)
                rows.append(fill_markov(s, pos, table))
            # evaluate through the same dynamic-padding loader
            class DS(torch.utils.data.Dataset):
                def __init__(self, rows):
                    self.seqs = rows
                    self.idx = list(range(len(rows)))

                def __len__(self):
                    return len(self.idx)

                def __getitem__(self, k):
                    i = self.idx[k]
                    return (torch.tensor(self.seqs[i], dtype=torch.float32).unsqueeze(-1),
                            int(y[te[i]]))
            dl = bucketed_loader(DS(rows), 512, False, 42)
            ys, ps = [], []
            with torch.no_grad():
                for xb, yb in dl:
                    ps.append(model(xb.to(dev)).argmax(1).cpu().numpy())
                    ys.append(yb.numpy())
            yt, yp = np.concatenate(ys), np.concatenate(ps)
            res[name][f"markov_{int(r*100)}"] = {
                "acc": round(float(accuracy_score(yt, yp)), 5),
                "f1_macro": round(float(f1_score(yt, yp, average="macro", zero_division=0)), 5),
            }
            print(name, r, res[name][f"markov_{int(r*100)}"], flush=True)
    json.dump(res, open(args.out, "w"), indent=2)


if __name__ == "__main__":
    main()
