﻿# -*- coding: utf-8 -*-
"""Deadline-oriented downstream run: CNN/GRU, dynamic padding, length buckets.

Conditions per test flow set (same identities, same mask positions):
  clean, delete_<r>, zero_<r>   for r in {10,20,30}%
Every model result is written immediately (metrics JSON + predictions + ckpt)
so a partial run is still deliverable.
"""
import argparse
import json
import pickle
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score
from torch.utils.data import DataLoader, Dataset

import models


class SeqDS(Dataset):
    def __init__(self, seqs, y, idxs, mask_ratio=0.0, mode="none", seed=42):
        self.seqs = seqs
        self.y = y
        self.idx = idxs
        self.mask_ratio = mask_ratio
        self.mode = mode
        self.seed = seed

    def __len__(self):
        return len(self.idx)

    def __getitem__(self, k):
        i = self.idx[k]
        s = self.seqs[i]
        if self.mode != "none" and self.mask_ratio > 0:
            rng = np.random.default_rng(self.seed + i)
            L = len(s)
            n = max(1, int(round(L * self.mask_ratio)))
            pos = rng.choice(L, size=n, replace=False)
            keep = np.ones(L, dtype=bool)
            keep[pos] = False
            if self.mode == "delete":
                seq = [v for j, v in enumerate(s) if keep[j]]
            else:  # zero pad
                arr = np.asarray(s, dtype=np.float32).copy()
                arr[pos] = 0.0
                seq = arr.tolist()
        else:
            seq = s
        return torch.tensor(seq, dtype=torch.float32).unsqueeze(-1), int(self.y[i])


def collate(batch):
    xs, ys = zip(*batch)
    lens = [x.size(0) for x in xs]
    L = max(lens)
    out = torch.zeros(len(xs), 1, L)
    for i, x in enumerate(xs):
        out[i, 0, : x.size(0)] = x[:, 0]
    return out, torch.tensor(ys)


def bucketed_loader(ds, batch, shuffle, seed):
    lens = [len(ds.seqs[i]) for i in ds.idx]
    order = np.argsort(lens)
    if shuffle:
        # shuffle inside length buckets of ~20*batch
        chunk = batch * 20
        chunks = [order[i: i + chunk] for i in range(0, len(order), chunk)]
        rng = np.random.default_rng(seed)
        for c in chunks:
            rng.shuffle(c)
        order = np.concatenate(chunks)
    return DataLoader(ds, batch_size=batch, sampler=order.tolist(),
                      collate_fn=collate, drop_last=shuffle)


def evaluate(model, loader, dev):
    model.eval()
    ys, ps = [], []
    with torch.no_grad():
        for xb, yb in loader:
            ps.append(model(xb.to(dev)).argmax(1).cpu().numpy())
            ys.append(yb.numpy())
    return np.concatenate(ys), np.concatenate(ps)


def report(y, p, n_cls):
    return {
        "acc": round(float(accuracy_score(y, p)), 5),
        "f1_macro": round(float(f1_score(y, p, average="macro", zero_division=0)), 5),
        "f1_weighted": round(float(f1_score(y, p, average="weighted", zero_division=0)), 5),
        "f1_micro": round(float(f1_score(y, p, average="micro", zero_division=0)), 5),
        "support": np.bincount(y, minlength=n_cls).tolist(),
        "confusion": confusion_matrix(y, p, labels=list(range(n_cls))).tolist(),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--models", default="cnn,gru")
    ap.add_argument("--epochs", type=int, default=20)
    ap.add_argument("--patience", type=int, default=4)
    ap.add_argument("--batch", type=int, default=256)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--threads", type=int, default=8)
    ap.add_argument("--splits", default="test")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    torch.set_num_threads(args.threads)
    dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    d = pickle.load(open(Path(args.data) / "raw.pkl", "rb"))
    seqs, y, labels = d["seqs"], d["y"], d["labels"]
    n_cls = len(labels)
    tr, va, te = d["split"]["train"], d["split"]["val"], d["split"]["test"]
    tr_set = {tuple(seqs[i]) for i in tr}
    unseen = [i for i in te if tuple(seqs[i]) not in tr_set]
    print(f'test rows {len(te)}, unseen-only rows {len(unseen)}', flush=True)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    conds = [("clean", "none", 0.0)]
    for r in (0.1, 0.2, 0.3):
        conds.append((f"delete_{int(r*100)}", "delete", r))
        conds.append((f"zero_{int(r*100)}", "zero", r))

    for name in args.models.split(","):
        torch.manual_seed(args.seed)
        t0 = time.time()
        model = models.build(name, n_cls).to(dev)
        opt = torch.optim.Adam(model.parameters(), lr=args.lr)
        lossf = nn.CrossEntropyLoss()
        dl_tr = bucketed_loader(SeqDS(seqs, y, tr), args.batch, True, args.seed)
        dl_va = bucketed_loader(SeqDS(seqs, y, va), 512, False, args.seed)

        hist, best, best_state, bad = [], -1.0, None, 0
        for ep in range(args.epochs):
            te0 = time.time()
            model.train()
            tot, n = 0.0, 0
            for xb, yb in dl_tr:
                xb, yb = xb.to(dev), yb.to(dev)
                opt.zero_grad()
                loss = lossf(model(xb), yb)
                loss.backward()
                opt.step()
                tot += float(loss) * len(yb)
                n += len(yb)
            yv, pv = evaluate(model, dl_va, dev)
            va_acc = float(accuracy_score(yv, pv))
            hist.append({"epoch": ep, "train_loss": round(tot / n, 4),
                         "val_acc": round(float(accuracy_score(yv, pv)), 4),
                         "seconds": round(time.time() - te0, 1)})
            print(f"{name} ep{ep} loss={tot/n:.4f} val_acc={hist[-1]['val_acc']} "
                  f"{hist[-1]['seconds']}s", flush=True)
            if va_acc > best + 1e-4:
                best, bad = va_acc, 0
                best_state = {k: v.detach().clone() for k, v in model.state_dict().items()}
            else:
                bad += 1
                if bad >= args.patience:
                    break
        if best_state:
            model.load_state_dict(best_state)

        res = {"model": name, "params": int(sum(p.numel() for p in model.parameters())),
               "epochs_run": len(hist), "seconds": round(time.time() - t0, 1),
               "seconds_per_epoch": round(float(np.mean([h["seconds"] for h in hist])), 2),
               "device": str(dev), "history": hist, "conditions": {}}
        for tag, mode, r in conds:
            ds = SeqDS(seqs, y, te, mask_ratio=r, mode=mode, seed=args.seed)
            dl = bucketed_loader(ds, 512, False, args.seed)
            yt, yp = evaluate(model, dl, dev)
            res["conditions"][tag] = report(yt, yp, n_cls)
            np.savez_compressed(out / f"{name}_{tag}.npz", y=yt, pred=yp)
            if unseen:
                dsu = SeqDS(seqs, y, unseen, mask_ratio=r, mode=mode, seed=args.seed)
                dlu = bucketed_loader(dsu, 512, False, args.seed)
                yu, pu = evaluate(model, dlu, dev)
                res["conditions"][tag + "_unseen"] = report(yu, pu, n_cls)

        json.dump(res, open(out / f"{name}.json", "w"), indent=2)
        torch.save({"state": model.state_dict(), "labels": labels}, out / f"{name}.pt")
        print(f"[saved] {name} in {res['seconds']}s", flush=True)

        # merge into a table whenever a model finishes
        rows = []
        for f in sorted(out.glob("*.json")):
            if f.name == "summary.json":
                continue
            r = json.load(open(f))
            rows.append(r)
        json.dump(rows, open(out / "summary.json", "w"), indent=2)
        ctags = [c[0] for c in conds]
        lines = ["| model | " + " | ".join(ctags) + " |", "|---" * (len(ctags) + 1) + "|"]
        for r in rows:
            lines.append("| " + r["model"] + " | " + " | ".join(
                f'{r["conditions"][c]["acc"]*100:.2f}/{r["conditions"][c]["f1_macro"]*100:.2f}'
                for c in ctags) + " |")
        (out / "table.md").write_text("\n".join(lines) + "\n")
        print("\n".join(lines), flush=True)


if __name__ == "__main__":
    main()
