﻿# -*- coding: utf-8 -*-
"""Build N鐪墂a datasets from cached flow sequences.

Outputs (per config):
  work/<tag>/pretrain.txt        one token sequence per line (length+1600)
  work/<tag>/train.npz           X (N,512) float32, y (N,)
  work/<tag>/test.npz            same for the held-out 20%
  work/<tag>/meta.json           counts, label map, config

Deviations from upstream are recorded in meta.json["notes"].
"""
import argparse
import re
import json
import pickle
import random
from collections import Counter
from pathlib import Path

import numpy as np
from sklearn.model_selection import train_test_split

MAXLEN = 512
OFFSET = 1600
MAXABS = 1600

# authors' default mapping (code/data_process/train_test_data.py)
USTC10 = {
    "Weibo": 0, "SMB": 1, "Virut": 2, "Htbot": 3, "Neris": 4,
    "Miuref": 5, "Nsis-ay": 6, "Zeus": 7, "Geodo": 8, "Shifu": 9,
}


def normalize_label(stem):
    """SMB-1/SMB-2 -> SMB, Weibo-3 -> Weibo; leaves Nsis-ay untouched."""
    m = re.match(r"^(.*?)-\d+$", stem)
    return m.group(1) if m else stem


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cache", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--min-len", type=int, default=20)
    ap.add_argument("--classes", default="all", help="'all' or comma separated labels")
    ap.add_argument("--max-per-class", type=int, default=0)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--val-frac", type=float, default=0.1)
    args = ap.parse_args()

    cache = pickle.load(open(args.cache, "rb"))
    keep = None
    if args.classes != "all":
        keep = {c.strip() for c in args.classes.split(",") if c.strip()}
    records = []
    for path, seqs in cache.items():
        label = normalize_label(Path(path).stem)
        if keep is not None and label not in keep:
            continue
        for i, s in enumerate(seqs):
            if len(s) >= args.min_len:
                records.append((label, s, f"{Path(path).name}#{i}"))

    rng = random.Random(args.seed)
    by_cls = {}
    for lab, s, fid in records:
        by_cls.setdefault(lab, []).append((s, fid))
    if args.max_per_class:
        for lab in by_cls:
            rng.shuffle(by_cls[lab])
            by_cls[lab] = by_cls[lab][: args.max_per_class]

    labels = sorted(by_cls)
    label2num = {l: i for i, l in enumerate(labels)}
    X, y, FID = [], [], []
    for lab in labels:
        for s, fid in by_cls[lab]:
            X.append(s)
            y.append(label2num[lab])
            FID.append(fid)
    y = np.asarray(y, dtype=np.int64)

    print("classes:", labels)
    print("counts:", dict(Counter([labels[i] for i in y])))

    idx_tr, idx_te = train_test_split(
        np.arange(len(X)), test_size=0.2, stratify=y, random_state=args.seed
    )
    if args.val_frac > 0:
        idx_tr, idx_va = train_test_split(
            idx_tr, test_size=args.val_frac, stratify=y[idx_tr], random_state=args.seed
        )
    else:
        idx_va = np.array([], dtype=np.int64)

    def pack(indices):
        arr = np.zeros((len(indices), MAXLEN), dtype=np.float32)
        for k, i in enumerate(indices):
            s = X[i][:MAXLEN]
            arr[k, : len(s)] = np.asarray(s, dtype=np.float32) / MAXABS
        return arr, y[indices]

    Xtr, ytr = pack(idx_tr)
    Xte, yte = pack(idx_te)

    # exact-duplicate (leak) check between train and test sequences
    tr_keys = {tuple(X[i][: min(len(X[i]), 512)]) for i in idx_tr}
    leak = sum(1 for i in idx_te if tuple(X[i][: min(len(X[i]), 512)]) in tr_keys)

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(out / "train.npz", X=Xtr, y=ytr)
    np.savez_compressed(out / "test.npz", X=Xte, y=yte)
    if len(idx_va):
        Xva, yva = pack(idx_va)
        np.savez_compressed(out / "val.npz", X=Xva, y=yva)
    for name, idx in (("train", idx_tr), ("val", idx_va), ("test", idx_te)):
        with open(out / f"{name}_ids.txt", "w") as f:
            for i in idx:
                f.write(f"{FID[i]}\t{labels[y[i]]}\n")
    with open(out / "pretrain.txt", "w") as f:
        for i in idx_tr:
            toks = [str(v + OFFSET) for v in X[i][:MAXLEN]]
            f.write(" ".join(toks) + "\n")
    meta = {
        "classes": labels,
        "label2num": label2num,
        "min_len": args.min_len,
        "max_len": MAXLEN,
        "max_abs_len": MAXABS,
        "offset": OFFSET,
        "n_train": int(len(idx_tr)),
        "n_val": int(len(idx_va)),
        "n_test": int(len(idx_te)),
        "exact_dup_train_test": int(leak),
        "seed": args.seed,
        "notes": [
            "token = clipped(signed_ip_len) + 1600",
            "sequences longer than 512 truncated, shorter zero padded",
            "split stratified 80/20 seed 42 (upstream default); val carved from train",
            "flow id = <pcap filename>#<flow index within file>",
        ],
    }
    json.dump(meta, open(out / "meta.json", "w"), indent=2)
    print("wrote", out, "train", Xtr.shape, "test", Xte.shape)


if __name__ == "__main__":
    main()
