# -*- coding: utf-8 -*-
"""Step 1: pcap -> per-session side-channel sequences (signed IP lengths).

Mirrors upstream: flowcontainer.extractor.extract(pcap, filter='tcp'),
keep sessions with >=20 packets and all |ip_len| <= 1600.
Writes one pickle per class: list[dict(seq, label, file)].
"""
import argparse
import os
import pickle
import time
from pathlib import Path

from flowcontainer.extractor import extract

MIN_PKTS = 20
MAX_ABS_LEN = 1600


def extract_pcap(path, clip=True):
    """Return (kept_sequences, n_flows, n_dropped_by_len).

    Paper wording: "cap the maximum packet length at 1600 bytes" -> we clip
    values to [-1600, 1600] (a capture-offload artefact makes raw IP lengths
    exceed the 1500B MTU). Upstream code instead *drops* any session that
    contains a >1600B packet; that variant is reported via n_dropped_by_len.
    """
    result = extract(str(path), filter="tcp")
    out, dropped = [], 0
    for key, value in result.items():
        lens = list(value.ip_lengths)
        if len(lens) < MIN_PKTS:
            continue
        if any(abs(x) > MAX_ABS_LEN for x in lens):
            if not clip:
                dropped += 1
                continue
            lens = [max(-MAX_ABS_LEN, min(MAX_ABS_LEN, x)) for x in lens]
        out.append(lens)
    return out, len(result), dropped


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True, help="dir containing class sub-dirs of pcaps")
    ap.add_argument("--out", required=True, help="output pickle")
    ap.add_argument("--limit", type=int, default=0, help="limit files per class (debug)")
    args = ap.parse_args()

    root = Path(args.root)
    records = []
    stats = {}
    for cls_dir in sorted(p for p in root.iterdir() if p.is_dir()):
        files = sorted(cls_dir.glob("*.pcap"))
        if args.limit:
            files = files[: args.limit]
        for f in files:
            t0 = time.time()
            try:
                seqs, nflows, ndrop = extract_pcap(f)
            except Exception as e:  # noqa: BLE001
                print(f"[ERR] {f}: {e}")
                continue
            for s in seqs:
                records.append({"seq": s, "label": cls_dir.name, "file": f.name})
            stats.setdefault(cls_dir.name, [0, 0])
            stats[cls_dir.name][0] += len(seqs)
            stats[cls_dir.name][1] += 1
            print(f"{f.parent.name}/{f.name}: flows={nflows} kept={len(seqs)} "
                  f"(time {time.time()-t0:.1f}s) total={len(records)}", flush=True)

    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    with open(args.out, "wb") as fh:
        pickle.dump(records, fh)
    print("\n=== summary ===")
    for k, (n, nf) in stats.items():
        print(f"{k:20s} sessions={n:7d} files={nf}")
    print("total", len(records), "->", args.out)


if __name__ == "__main__":
    main()
