# -*- coding: utf-8 -*-
"""Fast TCP session extraction with tshark's own tcp.stream index.

Why: flowcontainer re-parses every packet in Python (~1.5 MB/s) and needed
~40 min for the 3.4 GB aligned set, which does not fit the 12:00 deadline.
This uses `tshark -T fields` for a single streaming pass and groups packets
by Wireshark's tcp.stream id, which is the same session notion the upstream
pcap2TCP.py filter ("tcp.stream && not tcp.analysis.retransmission") implies.

Output: pickle {pcap_path: [ [signed ip_len, ...], ... ]} with the same
schema as cache_flows.py so build_dataset.py is unchanged.
"""
import pickle
import subprocess
import sys
import time
from collections import OrderedDict
from pathlib import Path

MAXABS = 1600


def extract(path):
    cmd = ["tshark", "-r", str(path), "-Y", "tcp", "-T", "fields",
           "-e", "tcp.stream", "-e", "ip.src", "-e", "ip.len", "-e", "tcp.flags"]
    p = subprocess.run(cmd, capture_output=True, text=True, errors="replace")
    sessions = OrderedDict()
    for line in p.stdout.splitlines():
        parts = line.split("\t")
        if len(parts) < 3:
            continue
        sid, src, ln = parts[0], parts[1], parts[2]
        try:
            ln = int(ln)
        except ValueError:
            continue
        if not sid:
            continue
        rec = sessions.get(sid)
        if rec is None:
            sessions[sid] = [src, [ln]]
        else:
            rec[1].append(ln if src == rec[0] else -ln)
    return [v[1] for v in sessions.values()]


def main():
    root = Path(sys.argv[1])
    out = Path(sys.argv[2])
    files = sorted(root.rglob("*.pcap"))
    print("files:", len(files), flush=True)
    cache = {}
    for f in files:
        t0 = time.time()
        try:
            seqs = extract(f)
        except Exception as e:  # noqa: BLE001
            print("[ERR]", f, e, flush=True)
            continue
        cache[str(f)] = seqs
        print(f"{f.relative_to(root)}: flows={len(seqs)} t={time.time()-t0:.1f}s", flush=True)
    with open(out, "wb") as fh:
        pickle.dump(cache, fh)
    print("saved", out, "files", len(cache), "flows", sum(len(v) for v in cache.values()))


if __name__ == "__main__":
    main()
