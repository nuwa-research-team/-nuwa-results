# -*- coding: utf-8 -*-
"""Build a raw (unpadded) dataset for dynamic-padding training.

Keeps every class that has at least `--min-count` sessions (default 20);
no class is dropped to flatter a score. Split: stratified 80/20 seed 42,
validation = 10% carved from train (never from test).
"""
import argparse
import json
import pickle
import re
from collections import Counter
from pathlib import Path

import numpy as np
from sklearn.model_selection import train_test_split

MAXLEN = 512
MAXABS = 1600


def normalize_label(stem):
    m = re.match(r"^(.*?)-\d+$", stem)
    return m.group(1) if m else stem


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cache", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--min-len", type=int, default=20)
    ap.add_argument("--min-count", type=int, default=20)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    cache = pickle.load(open(args.cache, "rb"))
    recs = []
    for path, seqs in sorted(cache.items()):
        lab = normalize_label(Path(path).stem)
        for i, s in enumerate(seqs):
            if len(s) >= args.min_len:
                recs.append((lab, [max(-MAXABS, min(MAXABS, v)) for v in s[:MAXLEN]],
                             f"{Path(path).name}#{i}"))

    cnt = Counter(r[0] for r in recs)
    keep = {k for k, v in cnt.items() if v >= args.min_count}
    dropped = {k: v for k, v in cnt.items() if v not in keep}
    recs = [r for r in recs if r[0] in keep]
    labels = sorted(keep)
    l2n = {l: i for i, l in enumerate(labels)}
    y = np.array([l2n[r[0]] for r in recs])
    ids = [r[2] for r in recs]
    seqs = [r[1] for r in recs]

    idx = np.arange(len(seqs))
    tr, te = train_test_split(idx, test_size=0.2, stratify=y, random_state=args.seed)
    tr, va = train_test_split(tr, test_size=0.1, stratify=y[tr], random_state=args.seed)

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    data = {
        "labels": labels,
        "seqs": seqs,
        "y": y,
        "ids": ids,
        "split": {"train": tr.tolist(), "val": va.tolist(), "test": te.tolist()},
    }
    pickle.dump(data, open(out / "raw.pkl", "wb"))

    trs = {tuple(seqs[i]) for i in tr}
    dup = sum(1 for i in te if tuple(seqs[i]) in trs)
    meta = {
        "n_total": len(seqs),
        "counts": {l: int(c) for l, c in sorted(cnt.items()) if l in keep},
        "dropped_small_classes": dropped,
        "n_train": len(tr), "n_val": len(va), "n_test": len(te),
        "min_len": args.min_len,
        "max_len": MAXLEN,
        "exact_dup_train_test": int(dup),
        "mean_len": float(np.mean([len(s) for s in seqs])),
        "p99_len": float(np.percentile([len(s) for s in seqs], 99)),
        "seed": args.seed,
        "notes": [
            "raw unpadded sequences for dynamic padding",
            "ip_len clipped to +/-1600",
            "retransmissions removed by tshark -2 filter upstream of tcp.stream grouping",
        ],
    }
    json.dump(meta, open(out / "meta.json", "w"), indent=2)
    print(json.dumps(meta, indent=2)[:1500])


if __name__ == "__main__":
    main()
