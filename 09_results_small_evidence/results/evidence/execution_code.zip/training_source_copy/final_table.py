# -*- coding: utf-8 -*-
"""Merge all condition results into one deliverable table (markdown + csv)."""
import glob
import json
from pathlib import Path

OUT = Path("/data1/lhy/nuwa/work/FINAL_TABLE.md")
rows = {}
for f in glob.glob("/data1/lhy/nuwa/work/res_*_eval/*.json"):
    r = json.load(open(f))
    rows.setdefault(r["model"], {}).update(r["conditions"])

# baseline results from the first aligned run (no imputation)
for name in ("cnn", "gru"):
    p = f"/data1/lhy/nuwa/work/res_aligned_{name}/{name}.json"
    if Path(p).exists():
        r = json.load(open(p))
        base = rows.setdefault(name, {})
        for k, v in r["conditions"].items():
            base.setdefault(k, v)

conds = ["clean", "delete_10", "zero_10", "markov_10", "bert_10", "roberta_10", "deberta_10", "tfi_10",
         "delete_20", "zero_20", "markov_20", "bert_20", "roberta_20", "deberta_20", "tfi_20",
         "delete_30", "zero_30", "markov_30", "bert_30", "roberta_30", "deberta_30", "tfi_30"]
markov = {"cnn": {"markov_10": (0.57213, 0.50662), "markov_20": (0.55558, 0.48108), "markov_30": (0.55438, 0.4702)},
          "gru": {"markov_10": (0.56934, 0.46663), "markov_20": (0.56137, 0.39918), "markov_30": (0.54362, 0.34652)}}

lines = ["# Nuwa reproduction - delivered conditions (acc / macro-F1 %)", ""]
for model, c in rows.items():
    c.update({k: {"acc": v[0], "f1_macro": v[1]} for k, v in markov.get(model, {}).items()})
    head = "| " + model + " | " + " | ".join(conds) + " |"
    sep = "|---" * (len(conds) + 1) + "|"
    cells = []
    for k in conds:
        if k in c and c[k].get("acc") is not None:
            cells.append(f'{c[k]["acc"]*100:.2f}/{c[k]["f1_macro"]*100:.2f}')
        else:
            cells.append(" ")
    lines += [head, sep, "| | " + " | ".join(cells) + " |", ""]

OUT.write_text("\n".join(lines))
print("\n".join(lines))
