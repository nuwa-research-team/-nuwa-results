﻿# -*- coding: utf-8 -*-
"""Pre-train the Traffic Feature Imputation model (TFI, DeBERTa MLM).

Disclosure is written to <out>/tfi_meta.json: which TFM variant was used,
whether disentangled relative attention is enabled, max_len, batch, lr,
data hash and wall-clock timings. Treat this as "declared approximation"
unless the flags match the paper exactly.
"""
import argparse
import hashlib
import json
import time
from pathlib import Path

import torch
from tokenizers import Tokenizer
from tokenizers.models import WordLevel
from tokenizers.pre_tokenizers import Whitespace
from tokenizers.trainers import WordLevelTrainer
from transformers import (DebertaConfig, DebertaForMaskedLM,
                          PreTrainedTokenizerFast, Trainer, TrainingArguments)

from tfm import TFMCollator


def sha256_file(path, chunk=1 << 20):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for blk in iter(lambda: f.read(chunk), b""):
            h.update(blk)
    return h.hexdigest()


class LineDataset(torch.utils.data.Dataset):
    def __init__(self, path, tokenizer, max_len=510):
        self.lines = [l.strip() for l in open(path) if l.strip()]
        self.tok = tokenizer
        self.max_len = max_len

    def __len__(self):
        return len(self.lines)

    def __getitem__(self, i):
        enc = self.tok(self.lines[i], truncation=True, max_length=self.max_len,
                       padding=False, return_special_tokens_mask=True)
        ids = enc["input_ids"]
        return {
            "input_ids": torch.tensor(ids),
            "special_tokens_mask": torch.tensor(enc["special_tokens_mask"]),
            "length": len(ids),
        }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True, help="pretrain.txt")
    ap.add_argument("--out", required=True)
    ap.add_argument("--layers", type=int, default=6)
    ap.add_argument("--epochs", type=float, default=3)
    ap.add_argument("--batch", type=int, default=128)
    ap.add_argument("--lr", type=float, default=1e-4)
    ap.add_argument("--tfm-mode", default="paper_tfm_approx",
                    choices=["paper_tfm_approx", "mlm_80_10_10", "released_source_repair"])
    ap.add_argument("--max-len", type=int, default=512)
    ap.add_argument("--relative-attention", action="store_true")
    ap.add_argument("--gpu", default="0")
    ap.add_argument("--grad-accum", type=int, default=1)
    ap.add_argument("--grad-ckpt", action="store_true")
    ap.add_argument("--arch", default="deberta", choices=["deberta", "bert", "roberta"])
    ap.add_argument("--vocab-from", default="")
    ap.add_argument("--smoke", action="store_true", help="2 steps only, for self-check")
    args = ap.parse_args()

    import os
    os.environ["CUDA_VISIBLE_DEVICES"] = args.gpu
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    if args.vocab_from:
        src = Path(args.vocab_from)
        tok_file = src / "model" / "wordlevel.json"
        if not tok_file.exists():
            tok_file = src / "wordlevel.json"
        tokenizer = PreTrainedTokenizerFast(
            tokenizer_file=str(tok_file),
            unk_token="<unk>", pad_token="<pad>", mask_token="<mask>",
            bos_token="<s>", eos_token="</s>")
        import shutil
        shutil.copy(str(tok_file), str(out / "wordlevel.json"))
    else:
        raw = Tokenizer(WordLevel(unk_token="<unk>"))
        raw.pre_tokenizer = Whitespace()
        trainer = WordLevelTrainer(
            special_tokens=["<s>", "<pad>", "</s>", "<unk>", "<mask>"], min_frequency=1)
        raw.train([args.data], trainer)
        raw.save(str(out / "wordlevel.json"))
        tokenizer = PreTrainedTokenizerFast(
            tokenizer_file=str(out / "wordlevel.json"),
            unk_token="<unk>", pad_token="<pad>", mask_token="<mask>",
            bos_token="<s>", eos_token="</s>")
    print("vocab", len(tokenizer))

    cfg_kwargs = dict(
        vocab_size=len(tokenizer),
        max_position_embeddings=args.max_len + 4,
        num_attention_heads=12,
        num_hidden_layers=args.layers,
        hidden_size=768,
        intermediate_size=3072,
    )
    if args.arch == "bert":
        from transformers import BertConfig, BertForMaskedLM
        config = BertConfig(**cfg_kwargs)
        model = BertForMaskedLM(config=config)
    elif args.arch == "roberta":
        from transformers import RobertaConfig, RobertaForMaskedLM
        config = RobertaConfig(**cfg_kwargs)
        model = RobertaForMaskedLM(config=config)
    else:
        config = DebertaConfig(type_vocab_size=0,
                               relative_attention=args.relative_attention, **cfg_kwargs)
        model = DebertaForMaskedLM(config=config)
    n_params = sum(p.numel() for p in model.parameters())
    print("params", round(n_params / 1e6, 2), "M")

    ds = LineDataset(args.data, tokenizer, max_len=args.max_len - 2)
    collator = TFMCollator(tokenizer, mlm_probability=0.15, mode=args.tfm_mode)

    targs = TrainingArguments(
        output_dir=str(out / "hf"),
        overwrite_output_dir=True,
        num_train_epochs=args.epochs,
        max_steps=2 if args.smoke else -1,
        per_device_train_batch_size=args.batch,
        gradient_accumulation_steps=args.grad_accum,
        learning_rate=args.lr,
        warmup_ratio=0.05,
        logging_steps=20,
        save_strategy="no",
        report_to=[],
        fp16=(dev == "cuda"),
        dataloader_num_workers=2,
        remove_unused_columns=False,
        gradient_checkpointing=args.grad_ckpt,
        group_by_length=True,
        length_column_name="length",
    )
    tr = Trainer(model=model, args=targs, data_collator=collator, train_dataset=ds)
    t0 = time.time()
    tr.train()
    train_seconds = time.time() - t0

    if not args.smoke:
        tr.save_model(str(out / "model"))
        tokenizer.save_pretrained(str(out / "model"))

    meta = {
        "data": str(args.data),
        "data_sha256": sha256_file(args.data),
        "n_lines": len(ds),
        "vocab": len(tokenizer),
        "params": n_params,
        "layers": args.layers,
        "heads": 12,
        "hidden_size": config.hidden_size,
        "intermediate_size": config.intermediate_size,
        "max_len": args.max_len,
        "relative_attention": args.relative_attention,
        "tfm_mode": args.tfm_mode,
        "epochs": args.epochs,
        "batch": args.batch,
        "lr": args.lr,
        "grad_accum": args.grad_accum,
        "effective_batch": args.batch * args.grad_accum,
        "device": dev,
        "gpu_used": args.gpu,
        "train_seconds": round(train_seconds, 1),
        "seconds_per_epoch": round(train_seconds / max(args.epochs, 1e-9), 1) if not args.smoke else None,
        "smoke": args.smoke,
        "disclosure": [
            "released pre-training.py did not wire the custom TFM; this file is a repair",
            "tfm_mode semantics documented in src/tfm.py header",
            "relative_attention=False matches the released script default; paper describes disentangled attention",
            "batch/lr follow paper (256 / 1e-4); actual batch may be reduced for memory, recorded above",
        ],
    }
    json.dump(meta, open(out / "tfi_meta.json", "w"), indent=2)
    print(json.dumps(meta, indent=2)[:1200])


if __name__ == "__main__":
    main()
