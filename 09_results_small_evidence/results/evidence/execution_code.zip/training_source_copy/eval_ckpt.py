﻿# -*- coding: utf-8 -*-
"""Evaluate frozen CNN/GRU checkpoints on imputed test sequences.

Conditions: clean, delete_r, zero_r (recomputed with the same masks) and
tfi_r / mlm_r loaded from impute.py outputs (<name>.seqs.pkl).
"""
import argparse
import json
import pickle
from pathlib import Path

import numpy as np
import torch
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score

import models
from train_fast import SeqDS, bucketed_loader


def eval_seq(model, seqs, idx, y, n_cls, dev):
    labels = [int(y[i]) for i in idx]
    class DS(torch.utils.data.Dataset):
        def __init__(self):
            self.seqs = seqs
            self.idx = list(range(len(seqs)))

        def __len__(self):
            return len(self.idx)

        def __getitem__(self, k):
            i = self.idx[k]
            return (torch.tensor(self.seqs[i], dtype=torch.float32).unsqueeze(-1),
                    labels[k])
    dl = bucketed_loader(DS(), 512, False, 42)
    ys, ps = [], []
    with torch.no_grad():
        for xb, yb in dl:
            ps.append(model(xb.to(dev)).argmax(1).cpu().numpy())
            ys.append(yb.numpy())
    yt, yp = np.concatenate(ys), np.concatenate(ps)
    return {
        "acc": round(float(accuracy_score(yt, yp)), 5),
        "f1_macro": round(float(f1_score(yt, yp, average="macro", zero_division=0)), 5),
        "f1_weighted": round(float(f1_score(yt, yp, average="weighted", zero_division=0)), 5),
        "f1_micro": round(float(f1_score(yt, yp, average="micro", zero_division=0)), 5),
        "support": np.bincount(yt, minlength=n_cls).tolist(),
        "confusion": confusion_matrix(yt, yp, labels=list(range(n_cls))).tolist(),
    }, yt, yp


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--ckpt_dirs", required=True, help="comma separated dirs holding <model>.pt")
    ap.add_argument("--imputed", default="", help="comma separated <name>=<path.npz.seqs.pkl>")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    d = pickle.load(open(Path(args.data) / "raw.pkl", "rb"))
    seqs, y, labels = d["seqs"], d["y"], d["labels"]
    n_cls, te = len(labels), d["split"]["test"]
    tr_set = {tuple(seqs[i]) for i in d["split"]["train"]}
    unseen = [i for i in te if tuple(seqs[i]) not in tr_set]

    imp = {}
    for spec in [s for s in args.imputed.split(",") if s]:
        name, path = spec.split("=", 1)
        obj = pickle.load(open(path, "rb"))
        imp[name] = obj["seqs"]

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    for ckdir in args.ckpt_dirs.split(","):
        for ck_path in sorted(Path(ckdir).glob("*.pt")):
            name = ck_path.stem
            ck = torch.load(ck_path, map_location=dev)
            model = models.build(name, n_cls).to(dev)
            model.load_state_dict(ck["state"])
            model.eval()
            res = {"model": name, "checkpoint": str(ck_path), "conditions": {}}

            cond_specs = [("clean", None, 0.0)]
            for r in (0.1, 0.2, 0.3):
                cond_specs += [(f"delete_{int(r*100)}", "delete", r),
                               (f"zero_{int(r*100)}", "zero", r)]
            for tag, mode, r in cond_specs:
                ds = SeqDS(seqs, y, te, mask_ratio=r, mode=mode, seed=42)
                class DS2(torch.utils.data.Dataset):
                    def __init__(self):
                        self.seqs = [seqs[i] for i in te]
                        self.idx = list(range(len(te)))

                    def __len__(self):
                        return len(self.idx)

                    def __getitem__(self, k):
                        return ds[k]
                dl = bucketed_loader(DS2(), 512, False, 42)
                ys, ps = [], []
                with torch.no_grad():
                    for xb, yb in dl:
                        ps.append(model(xb.to(dev)).argmax(1).cpu().numpy())
                        ys.append(yb.numpy())
                yt, yp = np.concatenate(ys), np.concatenate(ps)
                res["conditions"][tag] = {
                    "acc": round(float(accuracy_score(yt, yp)), 5),
                    "f1_macro": round(float(f1_score(yt, yp, average="macro", zero_division=0)), 5),
                    "f1_weighted": round(float(f1_score(yt, yp, average="weighted", zero_division=0)), 5),
                    "f1_micro": round(float(f1_score(yt, yp, average="micro", zero_division=0)), 5),
                }
                if tag == "clean":
                    np.savez_compressed(out / f"{name}_{tag}.npz", y=yt, pred=yp)

            for tag, seq_list in imp.items():
                m, yt, yp = eval_seq(model, seq_list, te, y, n_cls, dev)
                res["conditions"][tag] = {k: m[k] for k in
                                          ("acc", "f1_macro", "f1_weighted", "f1_micro")}
                np.savez_compressed(out / f"{name}_{tag}.npz", y=yt, pred=yp)


            json.dump(res, open(out / f"{name}.json", "w"), indent=2)
            print(json.dumps({k: v for k, v in res["conditions"].items()
                              if k.startswith(("clean", "tfi", "markov"))})[:400], flush=True)

    print("done", out)


if __name__ == "__main__":
    main()
