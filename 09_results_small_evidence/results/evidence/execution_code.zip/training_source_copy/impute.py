﻿# -*- coding: utf-8 -*-
"""Impute missing side-channel features with the pre-trained TFI model.

Given test sequences and a packet-loss ratio, produce
  X_mask   : lossy sequence, missing positions set to 0 (ZeroPad baseline)
  X_impute : same lossy sequence restored by TFI (Nuwa)
Both keep the same shape/normalisation as the clean input (x/1600).
"""
import argparse
import json
from pathlib import Path

import numpy as np
import torch
from transformers import (DebertaForMaskedLM, PreTrainedTokenizerFast)

MAXLEN = 512
OFFSET = 1600
MAXABS = 1600


def make_mask(seq_len, ratio, rng):
    k = max(1, int(round(seq_len * ratio)))
    return rng.choice(seq_len, size=k, replace=False)


@torch.no_grad()
def impute_batch(model, tok, seqs_int, device):
    """seqs_int: list[list[int]] with None at missing positions."""
    texts = []
    for s in seqs_int:
        toks = ["<mask>" if v is None else str(v + OFFSET) for v in s]
        texts.append(" ".join(toks))
    enc = tok(texts, padding="max_length", truncation=True, max_length=MAXLEN,
              return_tensors="pt")
    ids = enc["input_ids"].to(device)
    att = enc["attention_mask"].to(device)
    out = model(input_ids=ids, attention_mask=att).logits
    mask_pos = ids == tok.mask_token_id
    pred = out.argmax(-1)
    pred_tok = []
    for b in range(ids.size(0)):
        toks = [tok.convert_ids_to_tokens(int(t)) for t in pred[b][mask_pos[b]]]
        pred_tok.append(toks)

    results = []
    for b, s in enumerate(seqs_int):
        toks = list(pred_tok[b]) if b < len(pred_tok) else []
        vals = list(s)
        for i, v in enumerate(vals):
            if v is None:
                v2 = 0
                if toks:
                    t = toks.pop(0)
                    try:
                        v2 = int(t) - OFFSET
                    except (ValueError, TypeError):
                        v2 = 0
                vals[i] = v2
        results.append(vals)
    return results


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    ap.add_argument("--data", required=True, help="test.npz")
    ap.add_argument("--out", required=True)
    ap.add_argument("--ratio", type=float, default=0.1)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--batch", type=int, default=128)
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--gpu", default="0")
    args = ap.parse_args()

    import os
    if args.gpu != "":
        os.environ["CUDA_VISIBLE_DEVICES"] = args.gpu
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    tok = PreTrainedTokenizerFast.from_pretrained(args.model, local_files_only=True)
    model = DebertaForMaskedLM.from_pretrained(args.model, local_files_only=True).to(dev).eval()

    d = np.load(args.data)
    X, y = d["X"], d["y"]
    if args.limit:
        X, y = X[: args.limit], y[: args.limit]
    lens = (np.abs(X) > 0).sum(1)

    rng = np.random.default_rng(args.seed)
    mask_pos = [make_mask(int(L), args.ratio, rng) for L in lens]

    seqs = []
    for i in range(len(X)):
        s = [int(round(v * MAXABS)) for v in X[i][: int(lens[i])]]
        for p in mask_pos[i]:
            s[int(p)] = None
        seqs.append(s)

    filled = []
    for b in range(0, len(seqs), args.batch):
        filled.extend(impute_batch(model, tok, seqs[b : b + args.batch], dev))
        if b % (args.batch * 20) == 0:
            print("imputed", b, "/", len(seqs), flush=True)

    X_mask = np.zeros((len(seqs), MAXLEN), dtype=np.float32)
    X_imp = np.zeros((len(seqs), MAXLEN), dtype=np.float32)
    for i, s in enumerate(seqs):
        v = [0 if x is None else x for x in s]
        X_mask[i, : len(v)] = np.asarray(v, dtype=np.float32) / MAXABS
    for i, s in enumerate(filled):
        v = s[:MAXLEN]
        X_imp[i, : len(v)] = np.asarray(v, dtype=np.float32) / MAXABS

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(out, X_mask=X_mask, X_impute=X_imp, y=y,
                        lens=lens, ratio=args.ratio, seed=args.seed)
    import pickle as _pkl
    _pkl.dump({"seqs": filled, "y": y, "lens": lens, "ratio": args.ratio, "seed": args.seed},
              open(str(out) + ".seqs.pkl", "wb"))
    print("saved", out, X_mask.shape, "mean |imp-mask| =",
          float(np.abs(X_imp - X_mask).mean()))


if __name__ == "__main__":
    main()
