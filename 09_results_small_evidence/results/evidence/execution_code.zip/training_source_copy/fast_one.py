# -*- coding: utf-8 -*-
"""Extract one pcap -> pickle {path: [seq, ...]} (used by the parallel driver)."""
import pickle
import sys
import time
from pathlib import Path

from fast_sessions import extract

src = Path(sys.argv[1])
dst = Path(sys.argv[2])
dst.parent.mkdir(parents=True, exist_ok=True)
t0 = time.time()
seqs = extract(src)
pickle.dump({str(src): seqs}, open(dst, "wb"))
print(f"{src.name}: flows={len(seqs)} t={time.time()-t0:.1f}s", flush=True)
