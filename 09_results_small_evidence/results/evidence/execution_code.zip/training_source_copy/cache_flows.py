# -*- coding: utf-8 -*-
"""Cache ALL TCP flow length sequences per pcap (no filtering), so that
thresholds can be explored offline without re-running tshark.

Recurses into sub-directories so multi-part captures (Benign/SMB/SMB-1.pcap,
Benign/Weibo/Weibo-3.pcap) are included.
"""
import pickle
import sys
import time
from pathlib import Path

from flowcontainer.extractor import extract

root = Path(sys.argv[1])
out = Path(sys.argv[2])
cache = {}
files = sorted(root.rglob("*.pcap"))
print("files:", len(files), flush=True)
for f in files:
    t0 = time.time()
    try:
        r = extract(str(f), filter="tcp")
    except Exception as e:  # noqa: BLE001
        print("[ERR]", f, e, flush=True)
        continue
    seqs = [list(v.ip_lengths) for v in r.values()]
    cache[str(f)] = seqs
    print(f"{f.relative_to(root)}: flows={len(seqs)} t={time.time()-t0:.1f}s", flush=True)

with open(out, "wb") as fh:
    pickle.dump(cache, fh)
print("saved", out, "files", len(cache), "flows", sum(len(v) for v in cache.values()))
