import json
from pathlib import Path
from html import escape
from statistics import mean
from sklearn.metrics import accuracy_score,f1_score
P=Path(__file__).resolve().parents[1]
def load(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def lines(path):return [json.loads(l) for l in path.read_text().splitlines()]
ps=load(P/'predictions/classifiers.json'); packets=load(P/'results/packet_metrics.json')
rows=lines(P/'data/test.jsonl'); flow={r['id']:r for r in lines(P/'data/slice.jsonl')}
answers=lines(P/'predictions/missing_values.jsonl')
assert len(answers)==len(rows)==207 and all(a['id']==r['id'] for a,r in zip(answers,rows))
for method, reference in packets.items():
    for rate, expected in reference.items():
        errors=[]
        for row, answer in zip(rows,answers):
            if row['loss_rate']==float(rate):
                values=answer['missing_values'][method]
                assert len(values)==len(row['positions'])
                errors.extend(abs(abs(v)-abs(row['truth'][p])) for v,p in zip(values,row['positions']))
        assert abs(mean(errors)-expected)<1e-9
names={'cnn':'CNN','lstm':'LSTM','gru':'GRU','tst':'TST','sdae':'SDAE','fsnet':'FS-Net','RF':'随机森林','SVM':'RBF-SVM'}
methods={'Missing':'Baseline（未补全）','Nearest':'最近可见包','Linear':'线性插值','TFI':'本地 TFI','135M':'SmolLM2-135M LoRA','Gemini':'ReSTC · Gemini 3.8 Flash','Luna':'GPT-6 Luna · P2'}
methods={k:v for k,v in methods.items() if k in ps['cnn']}
rates=sorted({r['loss_rate'] for r in rows});groups=['Normal']+[f'Loss {r:.0%}' for r in rates]
def header():
    return '<thead><tr><th rowspan="2">Model</th>'+''.join(f'<th colspan="2">{g}</th>' for g in groups)+'</tr><tr>'+('<th>Acc (%)</th><th>F1 (%)</th>'*len(groups))+'</tr></thead>'
def tr(label,values,avg=False):
    return '<tr'+(' class="avg"' if avg else '')+'><th>'+escape(label)+'</th>'+''.join(f'<td title="{x:.9f}">{x:.2f}</td>' for x in values)+'</tr>'
def table(scope):
    scores={}
    for k,arms in ps.items():
        for arm in methods:
            values=[]
            for pos,rate in enumerate([rates[0]]+rates):
                ix=[i for i,r in enumerate(rows) if r['loss_rate']==rate and (scope=='all' or flow[r['flow']]['mode']==scope)]
                assert len({rows[i]['flow'] for i in ix})==len(ix)
                yt=[flow[rows[i]['flow']]['label'] for i in ix]
                yp=[arms[arm if pos else 'Normal'][i] for i in ix]
                values.extend([100*accuracy_score(yt,yp),100*f1_score(yt,yp,labels=sorted(set(yt)),average='macro',zero_division=0)])
            scores[k,arm]=values
    body=''.join(tr(names[k]+' · '+label,scores[k,a]) for k in ps for a,label in methods.items())
    for title,ks in [('Average（原六种）',list(names)[:6]),('Average（新增两种）',['RF','SVM'])]:
        for a,label in methods.items():
            values=list(map(mean,zip(*(scores[k,a] for k in ks))))
            body+=tr(title+' · '+label,values,True)
            if scope=='all':print(title,a,*[round(v,2) for v in values])
    return '<div class="scroll"><table>'+header()+'<tbody>'+body+'</tbody></table></div>'
doc='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>ISCXVPN2016 下游分类结果</title><style>body{max-width:1450px;margin:36px auto;padding:0 3.4%;color:#202520;font:17px/1.45 "Times New Roman",SimSun,serif}header{text-align:center}h1{font-size:26px;margin:8px}header p,footer,p.note{color:#646d64}header p{font-size:15px}.scroll{overflow:auto}table{width:100%;min-width:850px;border-collapse:collapse;border-top:1.7px solid;border-bottom:1.7px solid}thead{border-bottom:1.4px solid}thead tr+tr{border-top:1px solid}th,td{padding:5px 9px;text-align:center;font-weight:400}th:first-child{text-align:left}thead tr+tr th:first-child{text-align:center}thead tr:first-child th{font-size:21px}.avg>*{font-weight:bold}footer,details,.note{margin:14px 0}footer{font-size:14px}summary{cursor:pointer}@media print{body{max-width:none;font-size:11px}table{min-width:0}thead{display:table-header-group}tr{break-inside:avoid}}</style><header>TABLE I · CLASSIFICATION UNDER RANDOM PACKET LOSS<h1>ISCXVPN2016 · 缺包补全后的下游分类结果</h1><p>10% 分层切片 · 268 条训练流 · 69 条测试流 · 19 个测试采集组</p></header>'''
doc+=table('all')
doc+='<footer>Normal 使用完整流。Acc 为准确率，F1 为测试组中有真实样本类别的 macro-F1，均为百分数。每个模型与方法使用相同的 69 条测试流和同一档掩码。原六种使用 D4 特征提取器和 ISCX 训练的分类头，新增两种使用补全后的带方向包长序列。最近可见包在等距时取左侧，线性插值对带符号包长按位置插值并取整。</footer>'
if 'Gemini' in methods and 'Luna' in methods:
    counts={}
    for model in ('Gemini','Luna'):
        rec=lines(P/'predictions'/(model+'.jsonl')); counts[model]=sum(x['answer'] is not None for x in rec)
    doc+=f"<footer>模型输出有效数：Gemini {counts['Gemini']}/207，Luna {counts['Luna']}/207。无效输出在缺包位置按 0 回填并计分。ReSTC 按可见位置检索相同长度的 ISCX 训练流，最多 4 个示例。Luna P2 使用本地 D4 开发集选定的局部上下文与可见行为摘要。全部分类器共享每个方法的逐流补全结果。</footer>"
for scope,title in [('vpn','VPN · 25 条测试流'),('ordinary','普通流量 · 44 条测试流')]:
    doc+=f'<details><summary>{title}</summary>'+table(scope)+'</details>'
doc+='<details><summary>缺失位置的包长 MAE（字节）</summary><table><thead><tr><th>Model</th>'+''.join(f'<th>Loss {r:.0%}</th>' for r in rates)+'</tr></thead><tbody>'+''.join(tr(methods[k],[v[str(r)] for r in rates]) for k,v in packets.items())+'</tbody></table></details></html>'
(P/'results/comparison.html').write_text(doc,encoding='utf8')

