from pathlib import Path
import tempfile,tarfile,sys,json
import numpy as np, torch
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score,f1_score
from sklearn.pipeline import make_pipeline
P=Path(__file__).resolve().parents[1]
ROOT=P.parents[1]
N=ROOT/'nuwa_reproduction_20261109'
sys.path.extend(map(str,[N/'.deps',N/'shared',P.parent/'d4_downstream_random',P.parent/'restc_distillation_20261117/implementation/src']))
from transformers import AutoModelForMaskedLM,PreTrainedTokenizerFast
from restc_distill.common import checked_rows,read_lines,save,restore,file_hash
from paired_evaluation_v3 import mlm_fill
sys.path.insert(0,str(P.parent/'d4_downstream_random'))
import downstream as ds
rows,_=checked_rows(P/'prepared','test')
flows=read_lines(P/'slice.jsonl')
lookup={r['id']:r for r in flows}
train=[r for r in flows if r['split']=='train']
seqs=[r['truth'] for r in train];yt=[r['label'] for r in train]
names=sorted(set(yt))
assert not ({r['capture'] for r in train}&{lookup[r['flow']]['capture'] for r in rows})
torch.set_num_threads(4)
mask=np.zeros((len(rows),32),dtype=bool)
for i,r in enumerate(rows):mask[i,r['positions']]=True
with tempfile.TemporaryDirectory() as d,tarfile.open(P.parent/'d4_constrained_u1000_20261112/tfi_model.tar') as t:
    for name in ['config.json','pytorch_model.bin','tokenizer.json','special_tokens_map.json','tokenizer_config.json']:
        (Path(d)/name).write_bytes(t.extractfile('./'+name).read())
    assert file_hash(Path(d)/'pytorch_model.bin')==json.loads((P.parent/'d4_full_aligned_20261113/cloud_code/identity.json').read_text())['tfi']
    with torch.inference_mode():
        tfi,_=mlm_fill(AutoModelForMaskedLM.from_pretrained(d).eval(),PreTrainedTokenizerFast.from_pretrained(d),[[v or 0 for v in r['observed']] for r in rows],mask,'cpu',32)
pred={r['id']:r for r in read_lines(P/'predictions.jsonl')}
assert set(pred)=={r['id'] for r in rows} and len(pred)==len(rows)
student=[restore(r,pred[r['id']]['answer']) if pred[r['id']]['answer'] else [v or 0 for v in r['observed']] for r in rows]
arms={'Normal':[r['truth'] for r in rows],'Missing':[[v for v in r['observed'] if v is not None] for r in rows],'TFI':tfi,'135M':student}
def fill_visible(observed, nearest):
    indices=[i for i,v in enumerate(observed) if v is not None]
    values=[observed[i] for i in indices]
    if nearest:
        return [v if v is not None else observed[min(indices,key=lambda j:abs(i-j))] for i,v in enumerate(observed)]
    return np.rint(np.interp(np.arange(len(observed)),indices,values)).astype(int).tolist()
for method in ('Nearest','Linear'):
    arms[method]=[fill_visible(r['observed'],method=='Nearest') for r in rows]
out=P/'reproduction'
for arm in ('Gemini','Luna'):
    path=out/(arm+'.jsonl')
    if path.exists():
        cached={r['id']:r for r in read_lines(path)}
        assert set(cached)=={r['id'] for r in rows}
        arms[arm]=[restore(r,cached[r['id']]['answer']) if cached[r['id']]['answer'] else [v or 0 for v in r['observed']] for r in rows]
from torch import nn
preds={}
for k in ds.NAMES:
    net=ds.model_for(k,8);plain=k in ds.NAMES[:3]
    if plain:net.fc=nn.Identity()
    elif k=='fsnet':net.head[-1]=nn.Identity()
    elif k=='sdae':net.head=nn.Identity()
    else:net.base.output_layer=nn.Identity()
    def embed(seqs):
        blocks=[]
        with torch.inference_mode():
            for j in range(0,len(seqs),32):
                batch=seqs[j:j+32];x=torch.zeros(len(batch),32);length=torch.tensor(list(map(len,batch)))
                for i,s in enumerate(batch):x[i,:len(s)]=torch.tensor(s)
                blocks.append((net(x[:,None,:]) if plain else net(x/1600,length)).numpy())
        return np.concatenate(blocks)
    clf=make_pipeline(StandardScaler(),LogisticRegression(C=1,max_iter=500,random_state=42))
    clf.fit(embed(seqs),yt)
    preds[k]={arm:clf.predict(embed(s)).tolist() for arm,s in arms.items()}
    print(k,flush=True)
original=json.loads((P/'classifier_predictions.json').read_text())
for k in ds.NAMES:
    for arm,old in original[k].items():
        assert preds[k][arm]==old,(k,arm)
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
def positions(sequences):
    features=np.zeros((len(sequences),32))
    for i,s in enumerate(sequences):
        features[i,:len(s)]=s
    return features
for name,net in {
    'RF':RandomForestClassifier(n_estimators=300,random_state=42,n_jobs=2),
    'SVM':make_pipeline(StandardScaler(),SVC(C=1,kernel='rbf',gamma='scale')),
}.items():
    net.fit(positions(seqs),yt)
    preds[name]={method:net.predict(positions(values)).tolist() for method,values in arms.items()}
save(out/'predictions.json',preds)
save(out/'packet_metrics.json',{arm:{str(rate):float(np.mean([abs(abs(s[pos])-abs(r['truth'][pos])) for s,r in zip(sequences,rows) if r['loss_rate']==rate for pos in r['positions']])) for rate in (.1,.3,.5)} for arm,sequences in arms.items() if arm not in ('Normal','Missing')})

