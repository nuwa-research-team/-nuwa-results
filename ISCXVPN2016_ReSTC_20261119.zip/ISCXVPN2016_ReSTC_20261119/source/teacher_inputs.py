from pathlib import Path
from collections import defaultdict
import sys
P=Path(__file__).resolve().parent
A=P.parents[1]/'restc_distillation_20261117'
sys.path[:0]=[str(A/'implementation/src'),str(P.parents[2]/'tools/commandcode')]
from restc_distill.common import read_lines,read,checked_rows,digest,target_input,canonical,schema,save
from restc_distill.data import retrieve
from prompt_ablation import payload
rows,_=checked_rows(P.parent/'prepared','test')
cfg=read(A/'prepared/manifest.json')
system=cfg['config']['teacher_prompt']
system=Path(system).read_text(encoding='utf8')
bank=defaultdict(list);groups={}
for r in read_lines(P.parent/'slice.jsonl'):
    if r['split']=='train':
        g=digest(r['truth'])
        groups.setdefault(g,dict(group_id=g,truth=r['truth'],indices=[]))['indices'].append(r['id'])
for entry in groups.values():bank[len(entry['truth'])].append(entry)
teacher=cfg['config']['teacher'];reqs={'Luna':[],'Gemini':[]}
for r in rows:
    obs=r['observed'];pos=r['positions']
    assert [i for i,v in enumerate(obs) if v is None]==pos
    examples,ids=retrieve(obs,pos,bank[len(obs)],r['group_id'],cfg['config']['retrieval_k'])
    target=target_input(obs,pos)
    gem={'systemInstruction':{'parts':[{'text':system}]},'contents':[{'role':'user','parts':[{'text':canonical(dict(training_examples=examples,target=target))}]}],'generationConfig':dict(candidateCount=1,maxOutputTokens=teacher['max_output_tokens'],thinkingConfig=dict(thinkingLevel=teacher['thinking_level']),responseMimeType='application/json',responseJsonSchema=schema(pos))}
    luna=payload({'truth':[v or 0 for v in obs],'pos':pos},'P2')
    for k,body in [('Gemini',gem),('Luna',luna)]:
        reqs[k].append(dict(id=r['id'],positions=pos,request=body,hash=digest(body),retrieved=ids if k=='Gemini' else []))
for k,v in reqs.items():save(P/(k+'_requests.json'),v)
save(P/'teacher_protocol.json',dict(gemini=teacher,luna='gpt-6-luna / local dev-selected P2',flows=69,requests_per_model=len(rows),retrieval_train_flows=sum(len(x['indices']) for x in groups.values()),split_sha=digest(rows),fallback='invalid output fills masked positions with zero; API access errors halt'))
