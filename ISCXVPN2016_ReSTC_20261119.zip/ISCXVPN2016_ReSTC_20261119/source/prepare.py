from pathlib import Path
import collections, concurrent.futures, hashlib, json, random, re, struct, sys, zipfile
import dpkt
P=Path(__file__).resolve().parent
A=P.parent/'restc_distillation_20261117'
sys.path.insert(0,str(A/'implementation/src'))
from restc_distill.common import digest,student_messages,write_lines,save,read,file_hash

def category(name):
    s=Path(name).stem.lower()
    for label,terms in [('chat',('chat',)),('email',('email',)),('transfer',('scp','ftp','file')),('voip',('audio','voip','facebook_video','hangouts_video','skype_video')),('streaming',('youtube','vimeo','spotify','netflix')),('p2p',('bittorrent',))]:
        if any(t in s for t in terms): return label
    raise ValueError(name)

def parse(name):
    with zipfile.ZipFile(P/'raw/iscx.zip') as z,z.open(name) as f: parse_source(name,f)

def parse_source(name,f):
    out=P/'per_capture'/(Path(name).name+'.json')
    if out.exists(): return
    sessions={}; rows=[]; count=0
    def finish(value):
        ident,last,first,lengths=value
        if len(lengths)>=20 and max(map(abs,lengths))<=1600 and min(lengths)<0:
            rows.append([ident,lengths])
    if True:
        magic=f.read(4); f.seek(0)
        cap=dpkt.pcapng.Reader(f) if magic==b'\x0a\x0d\x0d\x0a' else dpkt.pcap.Reader(f)
        link=cap.datalink()
        if link not in (1,101,228,113): raise ValueError((name,link))
        for ts,b in cap:
            count+=1
            if link in (101,228):
                off=0
            else:
                off=14 if link==1 else 16
                if b[off-2:off] in (b"\x81\x00",b"\x88\xa8"): off+=4
                if b[off-2:off]!=b"\x08\x00": continue
            if len(b)<off+20 or b[off]>>4 != 4: continue
            proto=b[off+9]
            if proto not in (6,17) or int.from_bytes(b[off+6:off+8],'big')&0x3fff: continue
            ports=off+4*(b[off]&15)
            if len(b)<ports+4: continue
            src=b[off+12:off+16]+b[ports:ports+2]; dst=b[off+16:off+20]+b[ports+2:ports+4]
            key=(min(src,dst),max(src,dst),proto)
            v=sessions.get(key)
            if v is None or ts-v[1]>60:
                if v: finish(v)
                v=sessions[key]=[count,ts,src,[]]
            v[1]=ts
            if len(v[3])<32:
                n=int.from_bytes(b[off+2:off+4],'big')
                if n: v[3].append(n if src==v[2] else -n)
        for v in sessions.values(): finish(v)
    save(out,{'file':name,'packets':count,'rows':rows})
    print(name,len(rows),flush=True)

def main():
    with zipfile.ZipFile(P/'raw/iscx.zip') as z:
        names=[n for n in z.namelist() if n.lower().endswith(('.pcap','.pcapng'))]
    print('captures',len(names),flush=True)
    with concurrent.futures.ProcessPoolExecutor(6) as pool: list(pool.map(parse,names,chunksize=1))
    strata=collections.defaultdict(list)
    for name in sorted(names):
        label=category(name); mode='vpn' if Path(name).name.lower().startswith('vpn_') else 'ordinary'
        capture=re.sub(r'(?<=\d)[ab]$','',Path(name).stem.lower()).replace('hangouts','hangout')
        capture=re.sub(r'_[ab]$','',capture)
        for idx,seq in read(P/'per_capture'/(Path(name).name+'.json'))['rows']:
            ident=digest([name,idx]); strata[mode,label].append(dict(id=ident,file=name,capture=capture,mode=mode,label=label,truth=seq))
    total=sum(map(len,strata.values())); ns={k:len(v)//10 for k,v in strata.items()}
    for k in sorted(ns,key=lambda k: (-(len(strata[k])%10),k))[:round(total/10)-sum(ns.values())]: ns[k]+=1
    sampled=[]; support={}
    for k,rs in sorted(strata.items()):
        rs=sorted(rs,key=lambda r:digest([42,r['id']]))[:ns[k]]
        caps=sorted({r['capture'] for r in rs},key=lambda g:digest([42,g]))
        held=set(caps[:max(1,round(len(caps)*.25))]) if len(caps)>1 else set()
        for r in rs: r['split']='test' if r['capture'] in held else 'train'
        sampled+=rs;support['/'.join(k)]=[len(strata[k]),len(rs),len(held)]
    trainseq={digest(r['truth']) for r in sampled if r['split']=='train'}
    modelmeta=read(A/'student_results/smollm2-135m-instruct_lora/adapter_metadata.json')
    seen=trainseq|set(modelmeta['training_group_ids'])|set(modelmeta['validation_group_ids'])
    excluded=0; masks=[]
    for r in sampled:
        if r['split']!='test':continue
        seq=r['truth'];g=digest(seq)
        if g in seen:
            r['split']='excluded_duplicate';excluded+=1;continue
        for rate in (.1,.3,.5):
            rng=random.Random(int(digest([42,r['id'],rate]),16))
            pos=sorted(rng.sample(range(len(seq)),max(1,round(len(seq)*rate))))
            obs=[None if i in pos else v for i,v in enumerate(seq)]
            masks.append(dict(id=digest([r['id'],rate]),flow=r['id'],group_id=g,truth=seq,observed=obs,positions=pos,loss_rate=rate,messages=student_messages(obs,pos,modelmeta['student_system'])))
    write_lines(P/'slice.jsonl',sampled); prep=P/'prepared';write_lines(prep/'test.jsonl',masks)
    save(prep/'manifest.json',dict(student_system=modelmeta['student_system'],files={'test.jsonl':file_hash(prep/'test.jsonl')}))
    stats=dict(eligible=total,slice=len(sampled),capture_files=len(names),excluded=excluded,support=support,split=dict(collections.Counter(r['split'] for r in sampled)),test_inputs=len(masks))
    save(P/'inventory.json',stats);print(stats,flush=True)
if __name__=='__main__': main()


