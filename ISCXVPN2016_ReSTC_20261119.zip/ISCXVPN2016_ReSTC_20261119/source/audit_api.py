from pathlib import Path
import json, sys, collections, hashlib
import numpy as np
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parents[1]/'restc_distillation_20261117/implementation/src'))
from restc_distill.common import checked_rows,digest,read,read_lines,parse_answer,canonical,save
rows,_=checked_rows(P.parent/'prepared','test')
tr={digest(r['truth']) for r in read_lines(P.parent/'slice.jsonl') if r['split']=='train'}
flows={r['id']:r for r in read_lines(P.parent/'slice.jsonl')}
stats={};pr=read(P/'predictions.json')
for m,model in [('Luna','gpt-6-luna'),('Gemini','gemini-3.8-flash')]:
    inputs=read(P/(m+'_requests.json'));outputs=read_lines(P/(m+'.jsonl'))
    assert len(inputs)==len(outputs)==len(rows)==207
    counts=collections.Counter()
    for r,i,o in zip(rows,inputs,outputs,strict=True):
        assert r['id']==i['id']==o['id'] and i['positions']==r['positions']
        res=read(P/(m+'_responses')/(r['id']+'.json'))
        assert res['hash']==digest(i['request']) and res['answer']==o['answer']
        if m=='Gemini':
            assert res['response']['modelVersion']==model and set(i['retrieved'])<=tr
            assert hashlib.sha256(i['request']['systemInstruction']['parts'][0]['text'].encode()).hexdigest()=='5bb18543a86ef19b26251b79527b37f085950b4a1ff2ba976955fa171f3eab4b'
        else:
            assert res['response']['model']==model
            assert json.loads(i['request']['messages'][1]['content'])['signed']==r['observed']
        if o['answer']:parse_answer(canonical(o['answer']),r['positions']);counts['valid']+=1
        else:counts['invalid']+=1
    stats[m]=dict(counts)
stats['paired']=[]
for rate in (.1,.3,.5):
    ix=[j for j,r in enumerate(rows) if r['loss_rate']==rate]
    clusters=collections.defaultdict(list)
    for j in ix:
        f=flows[rows[j]['flow']]
        clusters[f['capture']].append(np.mean([float(pr[k]['Gemini'][j]==f['label'])-float(pr[k]['TFI'][j]==f['label']) for k in ('cnn','lstm','gru','tst','sdae','fsnet')]))
    v=np.array([(sum(xs),len(xs)) for xs in clusters.values()]);sam=np.random.default_rng(42).integers(len(v),size=(2000,len(v)));agg=v[sam].sum(1)
    stats['paired'].append(dict(rate=rate,gemini_minus_tfi_acc_pp=100*v[:,0].sum()/v[:,1].sum(),cluster_ci=np.quantile(100*agg[:,0]/agg[:,1],[.025,.975]).tolist()))
save(P/'api_audit.json',stats); print(stats)
