import os
from pathlib import Path
import json,sys
import torch,xgrammar as xgr
from xgrammar.contrib.hf import LogitsProcessor
from peft import PeftModel
from restc_distill.common import checked_rows,read,file_hash,parse_answer,canonical
from restc_distill.student import load_base,compile_output_grammar
P=Path(__file__).resolve().parent
adapter=Path(os.environ['RESTC_ADAPTER_DIR'])
meta=read(adapter/'restc.json')
assert file_hash(adapter/'adapter_model.safetensors')==meta['adapter_sha256']=='2adc9f8c52fa7f5893108a2f987f0cbb6a1a1a16096d6d8db39060aa66e387a2'
rows,manifest=checked_rows(P/'prepared','test')
assert manifest['student_system']==meta['student_system']
assert not ({r['group_id'] for r in rows}&set(meta['training_group_ids']+meta['validation_group_ids']))
model,tok=load_base(meta['config']);model=PeftModel.from_pretrained(model,str(adapter)).eval()
model.config.use_cache=True;tok.padding_side='left'
compiler=xgr.GrammarCompiler(xgr.TokenizerInfo.from_huggingface(tok,vocab_size=model.config.vocab_size,stop_token_ids=[tok.eos_token_id]))
out=P/'predictions.jsonl'
done={json.loads(line)['id'] for line in out.read_text().splitlines()} if out.exists() else set()
rows=sorted([r for r in rows if r['id'] not in done],key=lambda r:len(r['positions']))
with out.open('a') as f,torch.inference_mode():
    for start in range(0,len(rows),24):
        batch=rows[start:start+24]
        inp=tok.apply_chat_template([r['messages'] for r in batch],tokenize=True,add_generation_prompt=True,padding=True,return_tensors='pt',return_dict=True).to(model.device)
        grammar=LogitsProcessor([compile_output_grammar(compiler,r['positions']) for r in batch])
        pred=model.generate(**inp,do_sample=False,max_new_tokens=512,logits_processor=[grammar],pad_token_id=tok.pad_token_id,eos_token_id=tok.eos_token_id,temperature=None,top_p=None,top_k=None)
        texts=tok.batch_decode(pred[:,inp.input_ids.shape[1]:],skip_special_tokens=True)
        for r,t in zip(batch,texts,strict=True):
            try: ans=parse_answer(t,r['positions'])
            except ValueError: ans=None
            f.write(canonical(dict(id=r['id'],raw=t,answer=ans))+'\n')
        f.flush();print(start+len(batch),len(rows),flush=True)
