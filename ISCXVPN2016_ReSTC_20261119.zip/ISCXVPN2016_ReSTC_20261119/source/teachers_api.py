from pathlib import Path
import concurrent.futures as cf
import threading,sys,time,urllib.request,urllib.error,json
P=Path(__file__).resolve().parent
sys.path[:0]=[str(P.parents[1]/'restc_distillation_20261117/implementation/src'),str(P.parents[2]/'tools/commandcode')]
from restc_distill.common import read,save,write_lines,digest
from restc_distill.teacher import extract_answer
from compare import validate
from client import BASE,key
method=sys.argv[1];reqs=read(P/(method+'_requests.json')); dest=P/(method+'_responses')
tls=threading.local();stop=threading.Event()
if method=='Gemini':
    import google.auth
    from google.auth.transport.requests import AuthorizedSession
    teacher=read(P/'teacher_protocol.json')['gemini']
    url=f"https://aiplatform.googleapis.com/v1/projects/{teacher['project']}/locations/{teacher['location']}/publishers/google/models/{teacher['model']}:generateContent"
else:
    secret=key();url=BASE+'/chat/completions'
def run(r):
    path=dest/(r['id']+'.json')
    assert digest(r['request'])==r['hash']
    if path.exists():
        rec=read(path);assert rec['hash']==r['hash'];return rec
    for attempt in range(4):
        if stop.is_set():return
        try:
            if method=='Gemini':
                if not hasattr(tls,'sess'):
                    cred,_=google.auth.default(scopes=['https://www.googleapis.com/auth/cloud-platform'],quota_project_id=teacher['project'])
                    tls.sess=AuthorizedSession(cred);tls.sess.trust_env=False
                res=tls.sess.post(url,json=r['request'],timeout=(12,150));status=res.status_code;raw=res.json()
            else:
                req=urllib.request.Request(url,data=json.dumps(r['request']).encode(),headers={'Authorization':'Bearer '+secret,'Content-Type':'application/json','User-Agent':'NIDS-Research-CommandCode/1.0'})
                try:
                    with urllib.request.urlopen(req,timeout=150) as res:status=res.status;raw=json.load(res)
                except urllib.error.HTTPError as e:status=e.code;raw=json.loads(e.read())
            if status!=200:
                save(dest/'errors'/f"{r['id']}_{attempt}.json",dict(status=status,response=raw))
                if status in (429,500,502,503,504) and attempt<3:time.sleep(5*(attempt+1));continue
                raise RuntimeError('HTTP '+str(status))
            err=None;ans=None
            try:
                if method=='Gemini':ans=extract_answer(raw,r['positions'])
                else:
                    vs,err=validate(raw,len(r['positions']))
                    if vs is not None:ans={'values':dict(zip(map(str,r['positions']),vs))}
            except (ValueError,KeyError,TypeError) as e:err=str(e)
            rec=dict(id=r['id'],hash=r['hash'],response=raw,answer=ans,error=err)
            save(path,rec);return rec
        except Exception as e:
            if isinstance(e,RuntimeError) or attempt==3:stop.set();raise
            time.sleep(3*(attempt+1))
def main():
    run(reqs[0])
    with cf.ThreadPoolExecutor(max_workers=6) as pool:
        for i,_ in enumerate(pool.map(run,reqs),1):
            if i%20==0:print(method,i,flush=True)
    result=[read(dest/(r['id']+'.json')) for r in reqs]
    write_lines(P/(method+'.jsonl'),[dict(id=r['id'],answer=r['answer'],error=r['error']) for r in result])
    print('complete',len(result),'invalid',sum(not x['answer'] for x in result),flush=True)
if __name__=='__main__':main()
