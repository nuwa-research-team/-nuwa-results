# ISCXVPN2016 缺包补全实验

直接打开 [实验三线表](results/comparison.html)。正文给出八个分类器的逐项结果，展开可查看 VPN 与普通流量分项以及包长 MAE。

在 140 个抓包文件得到的 3,409 条合格流中，按业务与 VPN 状态分层抽取 341 条。268 条用于训练分类器输出层或传统分类器，剔除 4 条重复序列，69 条（19 个采集组）用于测试。每条流取首个 20–32 包窗口，在 10%、30%、50% 丢包率下共享掩码。原六种分类器使用冻结的 D4 特征提取器；新增随机森林与 RBF-SVM 在干净 ISCX 训练流上拟合。macro-F1 按评测子集中出现的类别计算。教师 Gemini 使用检索提示词，Luna 使用 P2。Luna 的 11 个缺包数不匹配答案按原规则填零并计入全部结果。

## 离线复算

在本目录运行以下命令，使用已保存的逐流预测核算包长 MAE、重算分类准确率与 macro-F1，并生成相同的 HTML。无需 GPU 或教师 API。

```sh
python -m pip install -r requirements.txt
python code/rebuild_table.py
```

- data 保存抽样流与掩码，predictions 保存分类与补全预测，prompts 保存两位教师实际输入。
- results 保存三线表和包长指标，provenance 保存下载来源、哈希、实验口径及审计结果。
- source 保存原研究工作区中的切流、推理、教师调用与评分脚本供追溯。重新推理需要原项目环境、D4 特征提取器、TFI 权重与已蒸馏的 135M adapter。离线复算入口为 code/rebuild_table.py。

## 数据与引用

ISCXVPN2016 由 University of New Brunswick 的 Canadian Institute for Cybersecurity 发布。[官方数据说明](https://www.unb.ca/cic/datasets/vpn.html)；本实验采用的[PCAP 镜像](https://www.kaggle.com/datasets/caiyafang/iscx-vpn-nonvpn-2016-complete-pcaps)。原包身份记录在 provenance/download_verified.json。引用 G. Draper-Gil et al., *Characterization of Encrypted and VPN Traffic using Time-related Features*, ICISSP 2016。模型与算法背景见 [ReSTC 项目](https://github.com/nuwa-research-team/ReSTC)。
